import { db } from '../lib/db'

async function makeAdmin(email: string) {
  try {
    console.log(`Looking for user with email: ${email}`)
    
    const user = await db.user.findUnique({
      where: { email }
    })

    if (!user) {
      console.log('User not found. Creating new admin user...')
      
      // Create a new admin user
      const newUser = await db.user.create({
        data: {
          email,
          name: 'Admin User',
          role: 'admin',
          onboardingCompleted: true,
          subscriptionTier: 'platinum',
          password: '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj3bp.Gm.F5e' // password: admin123
        }
      })
      
      console.log('✅ New admin user created successfully!')
      console.log(`Email: ${newUser.email}`)
      console.log(`Password: admin123`)
      console.log(`Role: ${newUser.role}`)
    } else {
      console.log('User found. Updating role to admin...')
      
      const updatedUser = await db.user.update({
        where: { email },
        data: { role: 'admin' }
      })
      
      console.log('✅ User role updated to admin successfully!')
      console.log(`Email: ${updatedUser.email}`)
      console.log(`Role: ${updatedUser.role}`)
    }
  } catch (error) {
    console.error('❌ Error making admin:', error)
  } finally {
    await db.$disconnect()
  }
}

// Get email from command line arguments
const email = process.argv[2]

if (!email) {
  console.log('Usage: npm run make-admin <email>')
  console.log('Example: npm run make-admin admin@example.com')
  process.exit(1)
}

makeAdmin(email)