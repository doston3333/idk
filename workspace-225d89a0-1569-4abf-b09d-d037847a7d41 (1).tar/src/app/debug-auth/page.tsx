'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/contexts/auth-context'
import { Loader2, User, CheckCircle, XCircle, AlertCircle } from 'lucide-react'

export default function DebugAuthPage() {
  const { user, login, logout, isLoading } = useAuth()
  const router = useRouter()
  const [debugInfo, setDebugInfo] = useState<any>({})
  const [isLoggingIn, setIsLoggingIn] = useState(false)

  useEffect(() => {
    // Collect debug information
    const info = {
      localStorageUser: localStorage.getItem('user'),
      contextUser: user,
      isLoading,
      timestamp: new Date().toISOString()
    }
    setDebugInfo(info)
  }, [user, isLoading])

  const handleAutoLogin = async () => {
    setIsLoggingIn(true)
    try {
      // Create a test user
      const testUser = {
        id: 'test-user-123',
        email: 'test@example.com',
        name: 'Test User',
        avatar: null,
        onboardingCompleted: true,
      }

      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(testUser))
      
      // Store in context
      login(testUser)
      
      // Wait a moment for state to update
      setTimeout(() => {
        router.push('/dashboard')
      }, 500)
    } catch (error) {
      console.error('Auto login failed:', error)
    } finally {
      setIsLoggingIn(false)
    }
  }

  const handleClearAuth = () => {
    logout()
    localStorage.clear()
    setDebugInfo({})
  }

  const handleCheckDashboard = () => {
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">🔧 Authentication Debug</h1>
          <p className="text-gray-600">Test and debug authentication flow</p>
        </div>

        {/* Current Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Current Authentication Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-medium">Loading State:</span>
              <Badge variant={isLoading ? "secondary" : "default"}>
                {isLoading ? 'Loading...' : 'Ready'}
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="font-medium">User Status:</span>
              {user ? (
                <Badge variant="default" className="bg-green-500">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Authenticated
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <XCircle className="w-3 h-3 mr-1" />
                  Not Authenticated
                </Badge>
              )}
            </div>

            {user && (
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-medium mb-2">User Data:</h4>
                <pre className="text-xs bg-white p-2 rounded border overflow-auto">
                  {JSON.stringify(user, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Debug Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Debug Information
            </CardTitle>
            <CardDescription>
              Technical details about authentication state
            </CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="text-xs bg-gray-50 p-4 rounded border overflow-auto">
              {JSON.stringify(debugInfo, null, 2)}
            </pre>
          </CardContent>
        </Card>

        {/* Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Test Actions</CardTitle>
            <CardDescription>
              Test different authentication scenarios
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button 
                onClick={handleAutoLogin} 
                disabled={isLoggingIn || !!user}
                className="w-full"
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging in...
                  </>
                ) : (
                  '🚀 Auto Login Test User'
                )}
              </Button>

              <Button 
                onClick={handleCheckDashboard} 
                disabled={!user}
                variant="outline"
                className="w-full"
              >
                📊 Go to Dashboard
              </Button>

              <Button 
                onClick={handleClearAuth} 
                variant="destructive"
                className="w-full"
              >
                🗑️ Clear Authentication
              </Button>

              <Button 
                onClick={() => window.location.reload()} 
                variant="secondary"
                className="w-full"
              >
                🔄 Reload Page
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>📋 Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <ol className="list-decimal list-inside space-y-1 text-sm">
              <li>Click "Auto Login Test User" to simulate authentication</li>
              <li>Check the debug information to see state changes</li>
              <li>Click "Go to Dashboard" to test redirect</li>
              <li>If redirect fails, use "Clear Authentication" and try again</li>
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}