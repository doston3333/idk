'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Utensils, 
  Heart, 
  MapPin, 
  User, 
  LogOut, 
  Settings, 
  TrendingUp,
  Share2,
  Star,
  Clock,
  Award,
  Target,
  Zap,
  Bell,
  Activity,
  DollarSign,
  Users,
  Calendar,
  AlertCircle,
  CheckCircle,
  XCircle
} from 'lucide-react'
import Link from 'next/link'

interface UserStats {
  totalSwipes: number
  totalLikes: number
  totalMatches: number
  totalShares: number
  referralStats: {
    totalGenerated: number
    totalUsed: number
  }
  recentActivity: Array<{
    type: string
    description: string
    timestamp: string
  }>
}

interface Notification {
  id: string
  type: 'info' | 'success' | 'warning' | 'error'
  title: string
  message: string
  timestamp: string
  read: boolean
}

export default function DemoDashboardPage() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'success',
      title: 'New Match!',
      message: 'You and Sarah both liked Spicy Tuna Roll',
      timestamp: '2 hours ago',
      read: false
    },
    {
      id: '2',
      type: 'info',
      title: 'New Dishes Available',
      message: '5 new dishes match your preferences',
      timestamp: '5 hours ago',
      read: false
    },
    {
      id: '3',
      type: 'warning',
      title: 'Referral Code Expiring',
      message: 'Your referral code expires in 3 days',
      timestamp: '1 day ago',
      read: true
    }
  ])

  const [showNotifications, setShowNotifications] = useState(false)

  // Mock user data
  const user = {
    name: 'Demo User',
    email: 'demo@foodiematch.com',
    role: 'user'
  }

  // Mock stats data
  const userStats: UserStats = {
    totalSwipes: 12,
    totalLikes: 8,
    totalMatches: 3,
    totalShares: 5,
    referralStats: {
      totalGenerated: 2,
      totalUsed: 1
    },
    recentActivity: [
      {
        type: 'swipe',
        description: 'Liked Truffle Pasta from Bella Italia',
        timestamp: '2 hours ago'
      },
      {
        type: 'match',
        description: 'New match with Sarah! You both like Spicy Tuna Roll',
        timestamp: '5 hours ago'
      },
      {
        type: 'share',
        description: 'Shared Margherita Pizza on WhatsApp',
        timestamp: '1 day ago'
      },
      {
        type: 'referral',
        description: 'Friend John joined using your referral code',
        timestamp: '2 days ago'
      }
    ]
  }

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    )
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'warning': return <AlertCircle className="h-4 w-4 text-yellow-500" />
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />
      default: return <Bell className="h-4 w-4 text-blue-500" />
    }
  }

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header with demo badge and notifications */}
        <div className="flex justify-between items-center">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-4xl font-bold">Welcome back, {user.name}! 🍽️</h1>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                Demo Mode
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Your food discovery journey continues. Here's what's happening today.
            </p>
          </div>
          <div className="flex gap-2">
            {/* Notifications */}
            <div className="relative">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </Button>
              
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border z-50 max-h-96 overflow-y-auto">
                  <div className="p-4 border-b">
                    <h3 className="font-semibold">Notifications</h3>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-gray-500">
                        No new notifications
                      </div>
                    ) : (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-4 border-b hover:bg-gray-50 cursor-pointer ${
                            !notification.read ? 'bg-blue-50' : ''
                          }`}
                          onClick={() => markNotificationAsRead(notification.id)}
                        >
                          <div className="flex items-start gap-3">
                            {getNotificationIcon(notification.type)}
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{notification.title}</h4>
                              <p className="text-xs text-gray-600 mt-1">{notification.message}</p>
                              <p className="text-xs text-gray-400 mt-1">{notification.timestamp}</p>
                            </div>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
            
            <Link href="/">
              <Button variant="outline">
                <LogOut className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Swipes</CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userStats.totalSwipes}</div>
              <p className="text-xs text-muted-foreground">
                +2 from yesterday
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Matches</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userStats.totalMatches}</div>
              <p className="text-xs text-muted-foreground">
                New connections made
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Dishes Shared</CardTitle>
              <Share2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userStats.totalShares}</div>
              <p className="text-xs text-muted-foreground">
                Spreading the love
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Referral Bonus</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${userStats.referralStats.totalUsed * 10}</div>
              <p className="text-xs text-muted-foreground">
                {userStats.referralStats.totalGenerated} friends invited
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Activity Score</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">85</div>
              <p className="text-xs text-muted-foreground">
                Very active
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Main Actions */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="discover" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="discover">Discover</TabsTrigger>
                <TabsTrigger value="growth">Growth</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
              </TabsList>

              <TabsContent value="discover" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Utensils className="h-5 w-5" />
                      Start Discovering
                    </CardTitle>
                    <CardDescription>
                      Ready to find your next favorite dish? Our AI has new recommendations for you!
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Link href="/discover">
                      <Button size="lg" className="w-full">
                        <Zap className="mr-2 h-5 w-5" />
                        Start Swiping Now
                      </Button>
                    </Link>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-orange-600">25</div>
                        <div className="text-xs text-gray-600">Daily Swipes</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-green-600">8</div>
                        <div className="text-xs text-gray-600">New Today</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-600">4.8</div>
                        <div className="text-xs text-gray-600">Avg Rating</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="growth" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Grow Your Network
                    </CardTitle>
                    <CardDescription>
                      Invite friends and earn rewards while expanding your foodie community.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <Users className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                          <div className="text-2xl font-bold">{userStats.referralStats.totalGenerated}</div>
                          <div className="text-sm text-gray-600">Friends Invited</div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-500" />
                          <div className="text-2xl font-bold">${userStats.referralStats.totalUsed * 10}</div>
                          <div className="text-sm text-gray-600">Earned</div>
                        </CardContent>
                      </Card>
                    </div>
                    <Button className="w-full">
                      <Share2 className="mr-2 h-4 w-4" />
                      Invite Friends & Earn $10
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="activity" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Recent Activity
                    </CardTitle>
                    <CardDescription>
                      Your latest food discovery actions and matches.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userStats.recentActivity.map((activity, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                          <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{activity.description}</p>
                            <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Column - Quick Actions & Insights */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/discover">
                  <Button variant="outline" className="w-full justify-start">
                    <Heart className="mr-2 h-4 w-4" />
                    Discover Dishes
                  </Button>
                </Link>
                <Link href="/matches">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="mr-2 h-4 w-4" />
                    View Matches
                  </Button>
                </Link>
                <Link href="/profile">
                  <Button variant="outline" className="w-full justify-start">
                    <User className="mr-2 h-4 w-4" />
                    Edit Profile
                  </Button>
                </Link>
                <Link href="/referrals">
                  <Button variant="outline" className="w-full justify-start">
                    <Award className="mr-2 h-4 w-4" />
                    Referral Program
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Achievement Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Achievement Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Food Explorer</span>
                    <span>12/20</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-orange-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Match Master</span>
                    <span>3/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Social Butterfly</span>
                    <span>5/15</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '33%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Features */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Coming Soon</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm">Premium Dish Reviews</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-blue-500" />
                  <span className="text-sm">Restaurant Check-ins</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Food Events Calendar</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Demo Info Footer */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <h3 className="font-semibold text-blue-900">Demo Dashboard</h3>
            </div>
            <p className="text-sm text-blue-800">
              This is a fully functional demo dashboard showing all features of FoodieMatch. 
              All data is simulated for demonstration purposes. In the real app, this data would be 
              connected to your actual user account and activity.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}