'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, X, Star, MapPin, DollarSign, Share2, Utensils } from 'lucide-react';
import ShareDish from '@/components/ShareDish';
import SwipeDeck from '@/components/swipe-deck';
import { useAuth } from '@/contexts/auth-context';

interface Dish {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  cuisine: string;
  restaurant: {
    id: string;
    name: string;
    address: string;
    rating: number;
  };
  rating: number;
  allergens?: string[];
  dietaryTags?: string[];
}

export default function DiscoverPage() {
  const { user } = useAuth();
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [loading, setLoading] = useState(true);
  const [remainingSwipes, setRemainingSwipes] = useState(100);
  const [maxDailySwipes] = useState(100);
  const [superLikesRemaining] = useState(5);
  const [subscriptionTier] = useState('free');

  useEffect(() => {
    fetchDishes();
  }, []);

  const fetchDishes = async () => {
    try {
      const response = await fetch('/api/recommendations');
      if (response.ok) {
        const data = await response.json();
        setDishes(data.dishes || []);
      }
    } catch (error) {
      console.error('Error fetching dishes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSwipe = async (candidateId: string, action: 'like' | 'pass' | 'super_like') => {
    try {
      const response = await fetch('/api/discover/swipe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          dishId: candidateId,
          action: action
        })
      });

      if (response.ok) {
        setRemainingSwipes(prev => Math.max(0, prev - 1));
        return { match: Math.random() > 0.8 }; // Simulate match for demo
      }
    } catch (error) {
      console.error('Error recording swipe:', error);
    }
  };

  const handleLoadMore = async () => {
    await fetchDishes();
  };

  // Convert dishes to SwipeDeck candidate format
  const candidates = dishes.map(dish => ({
    id: dish.id,
    type: 'dish' as const,
    name: dish.name,
    image: dish.image || `/api/placeholder/400/300/${dish.cuisine.toLowerCase()}`,
    cuisine: dish.cuisine,
    rating: dish.rating,
    description: dish.description,
    price: dish.price,
    priceRange: dish.price <= 10 ? 'low' : dish.price <= 20 ? 'medium' : 'high',
    address: dish.restaurant.address,
    dietaryTags: dish.dietaryTags || [],
    restaurant: {
      id: dish.restaurant.id,
      name: dish.restaurant.name,
      address: dish.restaurant.address,
      priceRange: dish.price <= 10 ? 'low' : dish.price <= 20 ? 'medium' : 'high'
    }
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
        <div className="max-w-md mx-auto">
          <div className="text-center py-20">
            <div className="animate-pulse">
              <div className="w-64 h-80 bg-gray-200 rounded-lg mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (candidates.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
        <div className="max-w-md mx-auto text-center py-20">
          <Utensils className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold mb-4">No dishes available!</h2>
          <p className="text-gray-600 mb-8">
            We couldn't find any dishes for you right now. Try refreshing!
          </p>
          <Button onClick={fetchDishes}>
            Refresh Recommendations
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Discover Dishes</h1>
          <p className="text-gray-600">
            Drag cards left or right to swipe • Use buttons for precise control
          </p>
        </div>

        {/* Swipe Deck */}
        <div className="h-[700px]">
          <SwipeDeck
            candidates={candidates}
            onSwipe={handleSwipe}
            onLoadMore={handleLoadMore}
            isLoading={loading}
            remainingSwipes={remainingSwipes}
            maxDailySwipes={maxDailySwipes}
            superLikesRemaining={superLikesRemaining}
            subscriptionTier={subscriptionTier}
          />
        </div>

        {/* Instructions */}
        <div className="text-center text-sm text-muted-foreground bg-white/50 rounded-lg p-4">
          <p className="font-medium mb-2">How to swipe:</p>
          <p>🖱️ <strong>Mouse:</strong> Click and drag cards left or right</p>
          <p>⌨️ <strong>Keyboard:</strong> ← Pass | ↑ Super Like | → Like</p>
          <p>📱 <strong>Touch:</strong> Swipe naturally on mobile devices</p>
        </div>
      </div>
    </div>
  );
}