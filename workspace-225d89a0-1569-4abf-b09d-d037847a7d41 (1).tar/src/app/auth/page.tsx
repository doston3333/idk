'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { LoginForm } from '@/components/auth/login-form'
import { SignupForm } from '@/components/auth/signup-form'
import { OnboardingWizard } from '@/components/auth/onboarding-wizard'
import { useAuth } from '@/contexts/auth-context'
import { safeRedirect, getDashboardUrl, needsOnboarding } from '@/lib/redirect-utils'

type AuthView = 'login' | 'signup' | 'onboarding'

export default function AuthPage() {
  const [currentView, setCurrentView] = useState<AuthView>('login')
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const { user: authUser, login } = useAuth()

  // Check if user is already logged in and needs onboarding
  useEffect(() => {
    if (authUser) {
      console.log('AuthPage: User already logged in', authUser)
      setUser(authUser)
      
      // Check if user needs onboarding
      if (needsOnboarding(authUser)) {
        console.log('AuthPage: User needs onboarding')
        setCurrentView('onboarding')
      } else {
        // User already completed onboarding, redirect to dashboard
        const dashboardUrl = getDashboardUrl(authUser.role)
        console.log('AuthPage: Redirecting to dashboard (already completed)', dashboardUrl)
        setTimeout(() => {
          safeRedirect(dashboardUrl)
        }, 100)
      }
    }
  }, [authUser])

  const handleLoginSuccess = (loggedInUser: any) => {
    console.log('AuthPage: Login successful', loggedInUser)
    setUser(loggedInUser)
    
    // Store user in AuthContext
    login(loggedInUser)
    
    // Check if user needs onboarding
    if (needsOnboarding(loggedInUser)) {
      setCurrentView('onboarding')
    } else {
      // Immediate redirect
      const dashboardUrl = getDashboardUrl(loggedInUser.role)
      console.log('AuthPage: Redirecting to dashboard', dashboardUrl)
      safeRedirect(dashboardUrl)
    }
  }

  const handleSignupSuccess = (userId: string, email: string, phone?: string) => {
    const newUser = {
      id: userId,
      email,
      phone,
      onboardingCompleted: false,
    }
    setUser(newUser)
    setCurrentView('onboarding')
  }

  const handleOnboardingComplete = (userDataWithRole?: any) => {
    // Update user state with role information if provided
    const finalUser = userDataWithRole || user
    console.log('AuthPage: handleOnboardingComplete called with', { userDataWithRole, user, finalUser })
    
    if (finalUser) {
      const updatedUser = { ...finalUser, onboardingCompleted: true }
      console.log('AuthPage: Updated user data', updatedUser)
      setUser(updatedUser)
      localStorage.setItem('user', JSON.stringify(updatedUser))
      
      // Store user in AuthContext
      login(updatedUser)
      
      // Get the appropriate dashboard URL and redirect
      const dashboardUrl = getDashboardUrl(updatedUser.role)
      console.log('AuthPage: Redirecting to dashboard after onboarding', dashboardUrl)
      
      // Use safe redirect for reliable navigation
      safeRedirect(dashboardUrl)
    } else {
      console.error('AuthPage: No final user data available')
      // Fallback to default dashboard
      safeRedirect('/dashboard')
    }
  }

  const switchToSignup = () => {
    setCurrentView('signup')
  }

  const switchToLogin = () => {
    setCurrentView('login')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="relative w-8 h-8">
              <img
                src="/logo.svg"
                alt="FoodieMatch Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <span className="text-xl font-bold">FoodieMatch</span>
          </div>
          
          {currentView === 'login' && (
            <h1 className="text-2xl font-bold text-gray-900">
              Welcome Back to Your Food Journey! 🍽️
            </h1>
          )}
          
          {currentView === 'signup' && (
            <h1 className="text-2xl font-bold text-gray-900">
              Start Your Food Adventure! 🌟
            </h1>
          )}
        </div>

        {/* Auth Content */}
        <div className="flex items-center justify-center">
          {currentView === 'login' && (
            <LoginForm
              onSuccess={handleLoginSuccess}
              onSwitchToSignup={switchToSignup}
            />
          )}
          
          {currentView === 'signup' && (
            <SignupForm
              onSuccess={handleSignupSuccess}
              onSwitchToPhone={() => {}} // TODO: Implement phone signup
            />
          )}
          
          {currentView === 'onboarding' && user && (
            <OnboardingWizard 
              onComplete={handleOnboardingComplete} 
              initialUserData={user}
            />
          )}
        </div>

        {/* Quick Access for Development */}
        {process.env.NODE_ENV === 'development' && (
          <div className="fixed bottom-4 right-4">
            <div className="bg-white border rounded-lg shadow-lg p-4 max-w-xs">
              <h3 className="font-semibold text-sm mb-2">🔧 Development Mode</h3>
              <div className="text-xs text-muted-foreground space-y-1">
                <p>• Any password works for login</p>
                <p>• Email verification skipped</p>
                <p>• Session stored in localStorage</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}