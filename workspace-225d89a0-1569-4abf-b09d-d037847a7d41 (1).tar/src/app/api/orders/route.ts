import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

// ============================================================================
// ORDERS API - Food Ordering System
// ============================================================================
// 
// This endpoint handles food ordering with third-party delivery service integration.
// It supports:
// - Creating new orders with delivery options
// - Order status tracking
// - Integration with delivery APIs (Uber Eats, DoorDash, etc.)
// - Payment processing through third-party services
// ============================================================================

interface CreateOrderRequest {
  userId: string
  restaurantId: string
  dishId?: string
  quantity?: number
  deliveryAddress: string
  specialNotes?: string
  deliveryOption: {
    id: string
    name: string
    estimatedTime: number
    fee: number
  }
  totalAmount: number
  orderItems?: Array<{
    dishId: string
    quantity: number
    specialNotes?: string
  }>
}

interface OrderResponse {
  order: {
    id: string
    status: string
    totalAmount: number
    estimatedTime: number
    deliveryAddress: string
    thirdPartyId?: string
    paymentUrl?: string
  }
  deliveryDetails: {
    provider: string
    estimatedTime: number
    trackingUrl?: string
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: CreateOrderRequest = await request.json()
    const {
      userId,
      restaurantId,
      dishId,
      quantity = 1,
      deliveryAddress,
      specialNotes,
      deliveryOption,
      totalAmount,
      orderItems
    } = body

    // ============================================================================
    // STEP 1: VALIDATE USER AND RESTAURANT
    // ============================================================================
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const restaurant = await db.restaurant.findUnique({
      where: { id: restaurantId },
      include: { dishes: true }
    })

    if (!restaurant) {
      return NextResponse.json(
        { error: 'Restaurant not found' },
        { status: 404 }
      )
    }

    // ============================================================================
    // STEP 2: VALIDATE ORDER ITEMS
    // ============================================================================
    let itemsToOrder = []

    if (dishId) {
      // Single dish order
      const dish = restaurant.dishes.find(d => d.id === dishId)
      if (!dish || !dish.isAvailable) {
        return NextResponse.json(
          { error: 'Dish not available' },
          { status: 400 }
        )
      }
      itemsToOrder.push({
        dishId,
        quantity,
        price: dish.price,
        specialNotes
      })
    } else if (orderItems && orderItems.length > 0) {
      // Multiple items order
      for (const item of orderItems) {
        const dish = restaurant.dishes.find(d => d.id === item.dishId)
        if (!dish || !dish.isAvailable) {
          return NextResponse.json(
            { error: `Dish ${item.dishId} not available` },
            { status: 400 }
          )
        }
        itemsToOrder.push({
          ...item,
          price: dish.price
        })
      }
    } else {
      return NextResponse.json(
        { error: 'No items specified for order' },
        { status: 400 }
      )
    }

    // ============================================================================
    // STEP 3: CREATE ORDER IN DATABASE
    // ============================================================================
    const order = await db.order.create({
      data: {
        userId,
        restaurantId,
        dishId: itemsToOrder[0]?.dishId, // Primary dish for single item orders
        deliveryAddress,
        totalAmount,
        deliveryFee: deliveryOption.fee,
        estimatedTime: deliveryOption.estimatedTime,
        specialNotes,
        status: 'pending',
        paymentStatus: 'pending'
      }
    })

    // Create order items
    await Promise.all(
      itemsToOrder.map(item =>
        db.orderItem.create({
          data: {
            orderId: order.id,
            dishId: item.dishId,
            quantity: item.quantity,
            price: item.price,
            specialNotes: item.specialNotes
          }
        })
      )
    )

    // ============================================================================
    // STEP 4: INTEGRATE WITH DELIVERY SERVICE
    // ============================================================================
    let thirdPartyOrder
    try {
      thirdPartyOrder = await createDeliveryOrder({
        orderId: order.id,
        restaurant,
        deliveryAddress,
        items: itemsToOrder,
        deliveryOption,
        customerInfo: {
          name: user.name || 'Customer',
          email: user.email,
          phone: user.phone
        }
      })
    } catch (error) {
      console.error('Delivery service error:', error)
      // Continue without third-party integration for demo
    }

    // ============================================================================
    // STEP 5: UPDATE ORDER WITH THIRD-PARTY DETAILS
    // ============================================================================
    if (thirdPartyOrder) {
      await db.order.update({
        where: { id: order.id },
        data: {
          thirdPartyId: thirdPartyOrder.id,
          status: 'confirmed',
          paymentStatus: 'pending_payment'
        }
      })
    }

    // ============================================================================
    // STEP 6: GENERATE PAYMENT LINK
    // ============================================================================
    const paymentUrl = await generatePaymentLink({
      orderId: order.id,
      amount: totalAmount,
      deliveryProvider: deliveryOption.name,
      thirdPartyOrderId: thirdPartyOrder?.id
    })

    // ============================================================================
    // STEP 7: SEND NOTIFICATIONS
    // ============================================================================
    await sendOrderNotifications({
      order,
      user,
      restaurant,
      deliveryOption
    })

    // ============================================================================
    // STEP 8: RETURN RESPONSE
    // ============================================================================
    const response: OrderResponse = {
      order: {
        id: order.id,
        status: order.status,
        totalAmount: order.totalAmount,
        estimatedTime: order.estimatedTime || deliveryOption.estimatedTime,
        deliveryAddress: order.deliveryAddress,
        thirdPartyId: thirdPartyOrder?.id,
        paymentUrl
      },
      deliveryDetails: {
        provider: deliveryOption.name,
        estimatedTime: deliveryOption.estimatedTime,
        trackingUrl: thirdPartyOrder?.trackingUrl
      }
    }

    return NextResponse.json(response)

  } catch (error) {
    console.error('Order creation error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ============================================================================
// GET ENDPOINT - ORDER STATUS AND HISTORY
// ============================================================================

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const orderId = searchParams.get('orderId')

    if (orderId) {
      // Get specific order
      const order = await db.order.findUnique({
        where: { id: orderId },
        include: {
          user: { select: { name: true, email: true } },
          restaurant: { select: { name: true, address: true, phone: true } },
          dish: { select: { name: true, image: true } },
          orderItems: {
            include: {
              dish: { select: { name: true, image: true, price: true } }
            }
          }
        }
      })

      if (!order) {
        return NextResponse.json(
          { error: 'Order not found' },
          { status: 404 }
        )
      }

      // Get real-time status from delivery service
      if (order.thirdPartyId) {
        const deliveryStatus = await getDeliveryStatus(order.thirdPartyId)
        return NextResponse.json({
          ...order,
          realTimeStatus: deliveryStatus
        })
      }

      return NextResponse.json(order)
    }

    if (userId) {
      // Get user's order history
      const orders = await db.order.findMany({
        where: { userId },
        include: {
          restaurant: { select: { name: true, image: true } },
          dish: { select: { name: true, image: true } },
          orderItems: {
            include: {
              dish: { select: { name: true, image: true } }
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: 20
      })

      return NextResponse.json({ orders })
    }

    return NextResponse.json(
      { error: 'userId or orderId parameter required' },
      { status: 400 }
    )

  } catch (error) {
    console.error('Order fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ============================================================================
// HELPER FUNCTIONS - THIRD-PARTY INTEGRATIONS
// ============================================================================

async function createDeliveryOrder(params: {
  orderId: string
  restaurant: any
  deliveryAddress: string
  items: any[]
  deliveryOption: any
  customerInfo: any
}) {
  // Mock implementation - in real app, integrate with actual delivery APIs
  console.log('Creating delivery order with params:', params)
  
  // Simulate API call to delivery service
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  return {
    id: `delivery_${Date.now()}`,
    trackingUrl: `https://track.delivery.com/${params.orderId}`,
    estimatedTime: params.deliveryOption.estimatedTime,
    status: 'confirmed'
  }
}

async function generatePaymentLink(params: {
  orderId: string
  amount: number
  deliveryProvider: string
  thirdPartyOrderId?: string
}) {
  // Mock implementation - in real app, integrate with payment processors
  console.log('Generating payment link for:', params)
  
  return `https://payment.foodiematch.com/pay/${params.orderId}?amount=${params.amount}`
}

async function sendOrderNotifications(params: {
  order: any
  user: any
  restaurant: any
  deliveryOption: any
}) {
  // Mock implementation - in real app, send emails, push notifications, etc.
  console.log('Sending order notifications:', params)
  
  // Send confirmation to user
  // Send notification to restaurant
  // Send to delivery service
}

async function getDeliveryStatus(thirdPartyId: string) {
  // Mock implementation - in real app, call delivery service API
  return {
    status: 'on_the_way',
    driverName: 'John Doe',
    driverPhone: '+1234567890',
    estimatedArrival: new Date(Date.now() + 25 * 60000).toISOString(),
    currentLocation: { lat: 40.7128, lng: -74.0060 }
  }
}