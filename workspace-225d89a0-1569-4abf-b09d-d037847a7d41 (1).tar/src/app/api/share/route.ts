import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const { userId, shareType, itemId, platform } = await request.json();

    if (!userId || !shareType || !platform) {
      return NextResponse.json({ 
        error: 'User ID, share type, and platform are required' 
      }, { status: 400 });
    }

    let dishId = null;
    let restaurantId = null;
    let deepLink = '';

    // Generate deep link based on share type
    switch (shareType) {
      case 'dish':
        dishId = itemId;
        deepLink = `https://foodiematch.app/dish/${itemId}?ref=${userId}`;
        break;
      case 'restaurant':
        restaurantId = itemId;
        deepLink = `https://foodiematch.app/restaurant/${itemId}?ref=${userId}`;
        break;
      case 'referral':
        // Get user's referral code
        const referral = await db.referralCode.findFirst({
          where: { referrerId: userId, isActive: true }
        });
        
        if (!referral) {
          return NextResponse.json({ 
            error: 'No active referral code found' 
          }, { status: 404 });
        }
        
        deepLink = `https://foodiematch.app/signup?ref=${referral.code}`;
        break;
      default:
        return NextResponse.json({ error: 'Invalid share type' }, { status: 400 });
    }

    // Create share action record
    const shareAction = await db.shareAction.create({
      data: {
        userId,
        dishId,
        restaurantId,
        shareType,
        platform,
        deepLink,
      }
    });

    // Track analytics event
    await db.analyticsEvent.create({
      data: {
        userId,
        eventType: 'share',
        eventName: `Shared ${shareType} on ${platform}`,
        properties: JSON.stringify({ 
          shareType,
          platform,
          deepLink,
          shareActionId: shareAction.id
        }),
      }
    });

    // Get shareable content based on type
    let shareContent = {};
    
    if (shareType === 'dish' && dishId) {
      const dish = await db.dish.findUnique({
        where: { id: dishId },
        include: {
          restaurant: { select: { name: true } }
        }
      });
      
      if (dish) {
        shareContent = {
          title: `Check out this amazing dish: ${dish.name}`,
          description: `I found this delicious dish at ${dish.restaurant.name} on FoodieMatch!`,
          image: dish.image,
          url: deepLink
        };
      }
    } else if (shareType === 'restaurant' && restaurantId) {
      const restaurant = await db.restaurant.findUnique({
        where: { id: restaurantId }
      });
      
      if (restaurant) {
        shareContent = {
          title: `Check out this restaurant: ${restaurant.name}`,
          description: `I discovered this amazing place on FoodieMatch!`,
          image: restaurant.image,
          url: deepLink
        };
      }
    } else if (shareType === 'referral') {
      shareContent = {
        title: 'Join me on FoodieMatch!',
        description: 'Use my referral link to get $10 off your first order!',
        url: deepLink
      };
    }

    return NextResponse.json({
      shareAction: {
        id: shareAction.id,
        deepLink: shareAction.deepLink,
        shareType: shareAction.shareType,
        platform: shareAction.platform
      },
      content: shareContent,
      message: 'Share link generated successfully'
    });

  } catch (error) {
    console.error('Error creating share link:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const shareActionId = searchParams.get('id');

    if (!shareActionId) {
      return NextResponse.json({ error: 'Share action ID is required' }, { status: 400 });
    }

    // Record click and get share action
    const shareAction = await db.shareAction.update({
      where: { id: shareActionId },
      data: { clicks: { increment: 1 } },
      include: {
        user: { select: { name: true } },
        dish: { 
          include: { restaurant: { select: { name: true } } }
        },
        restaurant: true
      }
    });

    if (!shareAction) {
      return NextResponse.json({ error: 'Share action not found' }, { status: 404 });
    }

    // Track analytics event
    await db.analyticsEvent.create({
      data: {
        eventType: 'share_clicked',
        eventName: 'Share Link Clicked',
        properties: JSON.stringify({ 
          shareActionId,
          shareType: shareAction.shareType,
          platform: shareAction.platform
        }),
      }
    });

    return NextResponse.json({
      deepLink: shareAction.deepLink,
      shareType: shareAction.shareType,
      clicks: shareAction.clicks
    });

  } catch (error) {
    console.error('Error processing share click:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}