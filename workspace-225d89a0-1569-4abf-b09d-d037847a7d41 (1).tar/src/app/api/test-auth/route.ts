import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST() {
  try {
    // Create a test customer user
    const hashedPassword = await bcrypt.hash('password123', 10)
    
    const customerUser = await db.user.create({
      data: {
        email: 'customer@test.com',
        name: 'Test Customer',
        password: hashedPassword,
        onboardingCompleted: true,
        role: 'user',
        emailVerified: true,
        subscriptionTier: 'free'
      }
    })

    // Create a test restaurant owner user
    const restaurantOwner = await db.user.create({
      data: {
        email: 'owner@test.com',
        name: 'Test Restaurant Owner',
        password: hashedPassword,
        onboardingCompleted: true,
        role: 'restaurant_owner',
        emailVerified: true,
        subscriptionTier: 'plus'
      }
    })

    return NextResponse.json({
      message: 'Test users created successfully',
      users: [
        {
          email: 'customer@test.com',
          password: 'password123',
          role: 'user'
        },
        {
          email: 'owner@test.com',
          password: 'password123',
          role: 'restaurant_owner'
        }
      ]
    })
  } catch (error) {
    console.error('Error creating test users:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const users = await db.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        onboardingCompleted: true,
        createdAt: true
      }
    })

    return NextResponse.json({ users })
  } catch (error) {
    console.error('Error fetching users:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}