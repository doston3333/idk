import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    const userId = formData.get('userId') as string

    if (!file || !userId) {
      return NextResponse.json(
        { error: 'File and userId are required' },
        { status: 400 }
      )
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Convert file to base64
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString('base64')
    const mimeType = file.type

    // AI-based image moderation
    const zai = await ZAI.create()
    
    // For now, we'll use a simple moderation check
    // In production, you'd use a more sophisticated image moderation service
    const moderationPrompt = `Analyze this image for appropriateness. Is this image suitable for a food dating app profile? 
    Check for: inappropriate content, violence, hate speech, nudity, or any content that would violate community guidelines.
    Respond with only "APPROVED" if the image is appropriate, or "REJECTED" if it's not appropriate.`

    try {
      // Note: This is a simplified approach. In production, you'd use a dedicated image moderation API
      const moderationResult = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: moderationPrompt
          },
          {
            role: 'user',
            content: `Analyze this image data: ${base64.substring(0, 100)}...`
          }
        ],
        max_tokens: 10,
      })

      const result = moderationResult.choices[0]?.message?.content?.trim()
      
      if (result === 'REJECTED') {
        return NextResponse.json(
          { error: 'Image rejected due to inappropriate content' },
          { status: 400 }
        )
      }
    } catch (moderationError) {
      console.error('Moderation error:', moderationError)
      // If moderation fails, we'll allow the upload but log the error
    }

    // Save image (in production, you'd use a cloud storage service like S3)
    // For now, we'll simulate the upload and return a placeholder URL
    const imageUrl = `/uploads/${userId}-${Date.now()}.${file.type.split('/')[1]}`

    // Update user avatar
    await db.user.update({
      where: { id: userId },
      data: { avatar: imageUrl },
    })

    return NextResponse.json({
      message: 'Image uploaded successfully',
      imageUrl,
    })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}