import { NextRequest, NextResponse } from 'next/server'

// Food image collection with diverse cuisines
const FOOD_IMAGES = {
  italian: [
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Pizza
    'https://images.unsplash.com/photo-1563379091339-0316a29577c2?w=400&h=400&fit=crop&auto=format', // Pasta
    'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=400&h=400&fit=crop&auto=format', // Lasagna
  ],
  japanese: [
    'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=400&fit=crop&auto=format', // Sushi
    'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&h=400&fit=crop&auto=format', // Ramen
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Tempura
  ],
  mexican: [
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Tacos
    'https://images.unsplash.com/photo-1553979459-222f2b4e4b91?w=400&h=400&fit=crop&auto=format', // Burrito
    'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400&h=400&fit=crop&auto=format', // Quesadilla
  ],
  indian: [
    'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400&h=400&fit=crop&auto=format', // Curry
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Biryani
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Naan
  ],
  chinese: [
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Dumplings
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Fried Rice
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Kung Pao
  ],
  american: [
    'https://images.unsplash.com/photo-1568901346376-cd95f4934a40?w=400&h=400&fit=crop&auto=format', // Burger
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Hot Dog
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // BBQ
  ],
  thai: [
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Pad Thai
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Tom Yum
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Green Curry
  ],
  mediterranean: [
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Greek Salad
    'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format', // Hummus
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format', // Falafel
  ]
}

// Default food images for any cuisine
const DEFAULT_FOOD_IMAGES = [
  'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1563379091339-0316a29577c2?w=400&h=400&fit=crop&auto=format',
  'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=400&fit=crop&auto=format'
]

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ params: string[] }> }
) {
  const resolvedParams = await params
  const [width, height, cuisine] = resolvedParams.params
  
  try {
    let imageUrl: string
    
    if (cuisine && FOOD_IMAGES[cuisine.toLowerCase()]) {
      // Get cuisine-specific image
      const cuisineImages = FOOD_IMAGES[cuisine.toLowerCase()]
      imageUrl = cuisineImages[Math.floor(Math.random() * cuisineImages.length)]
    } else {
      // Get random food image
      imageUrl = DEFAULT_FOOD_IMAGES[Math.floor(Math.random() * DEFAULT_FOOD_IMAGES.length)]
    }
    
    // Add size parameters to the URL
    const url = new URL(imageUrl)
    url.searchParams.set('w', width || '400')
    url.searchParams.set('h', height || '300')
    url.searchParams.set('fit', 'crop')
    url.searchParams.set('auto', 'format')
    
    // Fetch the image
    const response = await fetch(url.toString())
    
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.statusText}`)
    }
    
    const imageBuffer = await response.arrayBuffer()
    
    // Return the image with appropriate headers
    return new NextResponse(imageBuffer, {
      headers: {
        'Content-Type': response.headers.get('Content-Type') || 'image/jpeg',
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
    })
    
  } catch (error) {
    console.error('Image proxy error:', error)
    
    // Fallback to a default food image
    try {
      const fallbackUrl = `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=${width || 400}&h=${height || 300}&fit=crop&auto=format`
      const response = await fetch(fallbackUrl)
      
      if (response.ok) {
        const imageBuffer = await response.arrayBuffer()
        return new NextResponse(imageBuffer, {
          headers: {
            'Content-Type': response.headers.get('Content-Type') || 'image/jpeg',
            'Cache-Control': 'public, max-age=31536000, immutable',
          },
        })
      }
    } catch (fallbackError) {
      console.error('Fallback image also failed:', fallbackError)
    }
    
    // If everything fails, return a 404
    return new NextResponse('Image not found', { status: 404 })
  }
}