import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const onboardingSchema = z.object({
  userId: z.string(),
  dietaryRestrictions: z.array(z.string()).optional(),
  allergies: z.array(z.string()).optional(),
  favoriteCuisines: z.array(z.string()).optional(),
  priceRange: z.enum(['low', 'medium', 'high']).optional(),
  searchRadius: z.number().min(1).max(50).optional(),
  locationLat: z.number().optional(),
  locationLng: z.number().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      userId,
      dietaryRestrictions,
      allergies,
      favoriteCuisines,
      priceRange,
      searchRadius,
      locationLat,
      locationLng,
    } = onboardingSchema.parse(body)

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Update user preferences
    await db.user.update({
      where: { id: userId },
      data: {
        priceRange,
        searchRadius,
        locationLat,
        locationLng,
        onboardingCompleted: true,
      },
    })

    // Clear existing preferences
    await db.dietaryRestriction.deleteMany({
      where: { userId },
    })
    await db.allergy.deleteMany({
      where: { userId },
    })
    await db.favoriteCuisine.deleteMany({
      where: { userId },
    })

    // Add new preferences
    if (dietaryRestrictions?.length) {
      await db.dietaryRestriction.createMany({
        data: dietaryRestrictions.map(type => ({ userId, type })),
      })
    }

    if (allergies?.length) {
      await db.allergy.createMany({
        data: allergies.map(type => ({ userId, type })),
      })
    }

    if (favoriteCuisines?.length) {
      await db.favoriteCuisine.createMany({
        data: favoriteCuisines.map(type => ({ userId, type })),
      })
    }

    return NextResponse.json({
      message: 'Onboarding completed successfully',
    })
  } catch (error) {
    console.error('Onboarding error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}