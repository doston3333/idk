import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// For demo purposes, we'll use a mock user ID
// In production, you'd use proper authentication
const MOCK_USER_ID = 'demo-user-id'

export async function POST(request: NextRequest) {
  try {
    // For demo purposes, use mock user
    const user = await db.user.findFirst()
    
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const body = await request.json()
    const { dishId, action, restaurantId } = body

    if (!dishId || !action || !['like', 'pass', 'super_like'].includes(action)) {
      return NextResponse.json(
        { error: 'Invalid request parameters' },
        { status: 400 }
      )
    }

    // Check if user has reached daily swipe limit (for free users)
    if (user.subscriptionTier === 'free') {
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      
      const todaySwipes = await db.swipeAction.count({
        where: {
          userId: user.id,
          createdAt: { gte: today }
        }
      })

      if (todaySwipes >= 25) { // 25 swipes per day for free users
        return NextResponse.json(
          { error: 'Daily swipe limit reached' },
          { status: 429 }
        )
      }
    }

    // Check if super_like is available for premium users
    if (action === 'super_like' && user.subscriptionTier === 'free') {
      return NextResponse.json(
        { error: 'Super likes are only available for premium users' },
        { status: 403 }
      )
    }

    // Get the dish to find restaurant
    const dish = await db.dish.findUnique({
      where: { id: dishId },
      select: { restaurantId: true }
    })

    if (!dish) {
      return NextResponse.json({ error: 'Dish not found' }, { status: 404 })
    }

    // Create swipe action
    const swipeAction = await db.swipeAction.create({
      data: {
        userId: user.id,
        dishId,
        restaurantId: dish.restaurantId,
        action
      }
    })

    // Check for mutual likes (matches)
    let match = null
    if (action === 'like' || action === 'super_like') {
      // Find if someone else liked this dish
      const mutualLike = await db.swipeAction.findFirst({
        where: {
          dishId,
          action: { in: ['like', 'super_like'] },
          userId: { not: user.id }
        },
        include: {
          user: {
            select: { id: true, name: true, email: true, avatar: true }
          }
        }
      })

      if (mutualLike) {
        // Create match
        match = await db.match.create({
          data: {
            userId1: user.id,
            userId2: mutualLike.userId,
            dishId
          },
          include: {
            user1: {
              select: { id: true, name: true, email: true, avatar: true }
            },
            user2: {
              select: { id: true, name: true, email: true, avatar: true }
            },
            dish: {
              select: {
                id: true,
                name: true,
                image: true,
                restaurant: {
                  select: { name: true }
                }
              }
            }
          }
        })
      }
    }

    // Update user stats
    await db.user.update({
      where: { id: user.id },
      data: {
        // You could add swipe counts here if needed
      }
    })

    return NextResponse.json({
      success: true,
      swipeAction,
      match,
      remainingSwipes: user.subscriptionTier === 'free' 
        ? Math.max(0, 25 - (await db.swipeAction.count({
            where: {
              userId: user.id,
              createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) }
            }
          })))
        : -1 // Unlimited for premium
    })

  } catch (error) {
    console.error('Swipe action error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // For demo purposes, use mock user
    const user = await db.user.findFirst()
    
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get today's swipe count
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const todaySwipes = await db.swipeAction.count({
      where: {
        userId: user.id,
        createdAt: { gte: today }
      }
    })

    // Get super likes count for premium users
    const superLikesCount = user.subscriptionTier !== 'free' 
      ? await db.swipeAction.count({
          where: {
            userId: user.id,
            action: 'super_like',
            createdAt: { gte: today }
          }
        })
      : 0

    return NextResponse.json({
      dailySwipes: todaySwipes,
      maxDailySwipes: user.subscriptionTier === 'free' ? 25 : -1,
      superLikesCount,
      maxSuperLikes: user.subscriptionTier === 'platinum' ? 5 : 
                      user.subscriptionTier === 'gold' ? 3 : 
                      user.subscriptionTier === 'plus' ? 1 : 0,
      subscriptionTier: user.subscriptionTier
    })

  } catch (error) {
    console.error('Swipe stats error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}