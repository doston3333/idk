import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'
import { requireRole, getRestaurantForOwner } from '@/lib/auth-helpers'

const createDishSchema = z.object({
  name: z.string().min(2, 'Dish name must be at least 2 characters'),
  description: z.string().optional(),
  price: z.number().positive('Price must be positive'),
  cuisine: z.string().min(1, 'Cuisine is required'),
  image: z.string().url().optional(),
  allergens: z.array(z.string()).optional(),
  ingredients: z.array(z.string()).optional()
})

// GET - Get dishes for the current restaurant owner
export async function GET(request: NextRequest) {
  try {
    // Authenticate and authorize user
    const authResult = await requireRole(request, ['restaurant_owner'])
    if ('response' in authResult) {
      return authResult.response
    }
    const { user } = authResult

    // Find the restaurant for this owner
    const restaurant = await getRestaurantForOwner(user.id)
    if (!restaurant) {
      return NextResponse.json(
        { error: 'No restaurant found for this owner' },
        { status: 404 }
      )
    }

    // Get dishes only for this restaurant
    const dishes = await db.dish.findMany({
      where: {
        restaurantId: restaurant.id
      },
      include: {
        restaurant: {
          select: {
            name: true
          }
        },
        dishIngredients: {
          select: {
            name: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 50 // Limit to 50 most recent dishes
    })

    // Format the response to include ingredients as an array
    const formattedDishes = dishes.map(dish => ({
      ...dish,
      allergens: dish.allergens ? JSON.parse(dish.allergens) : [],
      ingredients: dish.dishIngredients.map(ing => ing.name)
    }))

    return NextResponse.json(formattedDishes)
  } catch (error) {
    console.error('Error fetching dishes:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dishes' },
      { status: 500 }
    )
  }
}

// POST - Create a new dish
export async function POST(request: NextRequest) {
  try {
    // Authenticate and authorize user
    const authResult = await requireRole(request, ['restaurant_owner'])
    if ('response' in authResult) {
      return authResult.response
    }
    const { user } = authResult

    const body = await request.json()
    const { name, description, price, cuisine, image, allergens, ingredients } = createDishSchema.parse(body)

    // Find or create restaurant for this owner
    let restaurant = await getRestaurantForOwner(user.id)
    
    if (!restaurant) {
      // Create a restaurant for this owner
      restaurant = await db.restaurant.create({
        data: {
          name: `${user.name || user.email}'s Restaurant`,
          description: 'Restaurant managed by the owner',
          address: '123 Food Street, Culinary City, CC 12345',
          lat: 40.7128,
          lng: -74.0060,
          phone: '+1-555-0123',
          email: user.email,
          priceRange: 'medium',
          isActive: true,
          ownerId: user.id
        }
      })
    }

    // Create the dish
    const dish = await db.dish.create({
      data: {
        name,
        description,
        price,
        cuisine,
        image: image || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop&crop=center`,
        restaurantId: restaurant.id,
        isActive: true,
        isAvailable: true,
        allergens: allergens && allergens.length > 0 ? JSON.stringify(allergens) : null
      },
      include: {
        restaurant: {
          select: {
            name: true
          }
        }
      }
    })

    // Add ingredients if provided
    if (ingredients && ingredients.length > 0) {
      await Promise.all(
        ingredients.map(ingredient =>
          db.dishIngredient.create({
            data: {
              dishId: dish.id,
              name: ingredient.trim()
            }
          })
        )
      )
    }

    // Fetch the complete dish with ingredients
    const completeDish = await db.dish.findUnique({
      where: { id: dish.id },
      include: {
        restaurant: {
          select: {
            name: true
          }
        },
        dishIngredients: {
          select: {
            name: true
          }
        }
      }
    })

    // Format the response
    const formattedDish = {
      ...completeDish,
      allergens: completeDish?.allergens ? JSON.parse(completeDish.allergens) : [],
      ingredients: completeDish?.dishIngredients.map(ing => ing.name) || []
    }

    return NextResponse.json({
      success: true,
      dish: formattedDish,
      message: 'Dish created successfully'
    })

  } catch (error) {
    console.error('Error creating dish:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Failed to create dish' },
      { status: 500 }
    )
  }
}

// PATCH - Update a dish (activate/deactivate)
export async function PATCH(request: NextRequest) {
  try {
    // Authenticate and authorize user
    const authResult = await requireRole(request, ['restaurant_owner'])
    if ('response' in authResult) {
      return authResult.response
    }
    const { user } = authResult

    const body = await request.json()
    const { dishId, isActive } = body

    if (!dishId) {
      return NextResponse.json(
        { error: 'Dish ID is required' },
        { status: 400 }
      )
    }

    // Find the restaurant for this owner
    const restaurant = await getRestaurantForOwner(user.id)
    if (!restaurant) {
      return NextResponse.json(
        { error: 'No restaurant found for this owner' },
        { status: 404 }
      )
    }

    // Check if the dish belongs to this owner's restaurant
    const existingDish = await db.dish.findFirst({
      where: {
        id: dishId,
        restaurantId: restaurant.id
      }
    })

    if (!existingDish) {
      return NextResponse.json(
        { error: 'Dish not found or access denied' },
        { status: 404 }
      )
    }

    const updatedDish = await db.dish.update({
      where: { id: dishId },
      data: { isActive },
      select: {
        id: true,
        name: true,
        price: true,
        cuisine: true,
        isActive: true,
        isAvailable: true,
        createdAt: true
      }
    })

    return NextResponse.json({
      success: true,
      dish: updatedDish,
      message: 'Dish updated successfully'
    })

  } catch (error) {
    console.error('Error updating dish:', error)
    return NextResponse.json(
      { error: 'Failed to update dish' },
      { status: 500 }
    )
  }
}