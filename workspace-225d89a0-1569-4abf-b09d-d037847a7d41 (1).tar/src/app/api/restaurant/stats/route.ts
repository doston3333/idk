import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireRole, getRestaurantForOwner } from '@/lib/auth-helpers'

export async function GET(request: NextRequest) {
  try {
    // Authenticate and authorize user
    const authResult = await requireRole(request, ['restaurant_owner'])
    if ('response' in authResult) {
      return authResult.response
    }
    const { user } = authResult

    // Find the restaurant for this owner
    const restaurant = await getRestaurantForOwner(user.id)
    if (!restaurant) {
      // Return empty stats for owners without restaurants
      const emptyStats = {
        totalDishes: 0,
        totalOrders: 0,
        totalReviews: 0,
        activeDishes: 0,
        averageRating: 0,
        monthlyViews: 0
      }
      return NextResponse.json(emptyStats)
    }

    // Get basic stats for this restaurant owner only
    const [
      totalDishes,
      totalOrders,
      totalReviews,
      activeDishes
    ] = await Promise.all([
      db.dish.count({
        where: { restaurantId: restaurant.id }
      }),
      db.order.count({
        where: {
          dish: {
            restaurantId: restaurant.id
          }
        }
      }),
      db.review.count({
        where: {
          dish: {
            restaurantId: restaurant.id
          }
        }
      }),
      db.dish.count({
        where: {
          restaurantId: restaurant.id,
          isActive: true,
          isAvailable: true
        }
      })
    ])

    // Calculate average rating for this restaurant's dishes only
    const reviews = await db.review.findMany({
      where: {
        dish: {
          restaurantId: restaurant.id
        }
      },
      select: { rating: true }
    })
    
    const averageRating = reviews.length > 0 
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
      : 0

    // For monthly views, we'll use a simple approach for now
    // In a real app, you'd track views in a separate table
    const monthlyViews = Math.floor(Math.random() * 1000)

    const stats = {
      totalDishes,
      totalOrders,
      totalReviews,
      activeDishes,
      averageRating,
      monthlyViews
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error('Error fetching restaurant stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}