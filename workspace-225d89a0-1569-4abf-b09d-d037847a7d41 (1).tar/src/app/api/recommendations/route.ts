import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  computeCandidateScore,
  injectExplorationItems,
  calculateDistance,
  calculateScoreDistribution,
  validateScoringWeights,
  DEFAULT_SCORING_WEIGHTS,
  DEFAULT_ALGORITHM_CONFIG,
  type ScoringWeights,
  type AlgorithmConfig,
  type CandidateScore
} from '@/lib/recommendation-scoring'

// ============================================================================
// RECOMMENDATION API - Default Mode
// ============================================================================
// 
// This endpoint provides intelligent candidate recommendations for the swipe deck.
// It uses a multi-factor scoring algorithm that considers:
// 1. Taste Match (user preferences vs dish attributes) - 35%
// 2. Recency (newly added items get boosted) - 20%
// 3. Popularity (like/save ratios) - 25%
// 4. Fairness/Diversity (boosts underrepresented cuisines) - 15%
// 5. Exploration (injects random/trending items) - 5%
//
// Algorithm is designed to be extensible - new scoring factors can be added
// without breaking existing functionality.
// ============================================================================

interface RecommendationRequest {
  user_id?: string
  latitude?: number
  longitude?: number
  category_filters?: string[]
  limit?: number
  exploration_quota?: number // Percentage of random items (0-100)
  scoring_weights?: Partial<ScoringWeights>
  algorithm_config?: Partial<AlgorithmConfig>
}

interface RecommendationResponse {
  recommendations: any[]
  metadata: {
    totalCandidates: number
    explorationItemsInjected: number
    averageScore: number
    scoreDistribution: {
      high: number
      medium: number
      low: number
    }
    algorithmVersion: string
    scoringWeights: ScoringWeights
    algorithmConfig: AlgorithmConfig
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: RecommendationRequest = await request.json()
    const {
      user_id,
      latitude = 40.7128, // Default: NYC
      longitude = -74.0060,
      category_filters = [],
      limit = 20,
      exploration_quota = DEFAULT_ALGORITHM_CONFIG.defaultExplorationQuota,
      scoring_weights = {},
      algorithm_config = {}
    } = body

    // ============================================================================
    // STEP 1: VALIDATE USER AND FETCH PREFERENCES
    // ============================================================================
    if (!user_id) {
      return NextResponse.json(
        { error: 'user_id is required' },
        { status: 400 }
      )
    }

    // Get user with all preferences for taste matching
    const user = await db.user.findUnique({
      where: { id: user_id },
      include: {
        dietaryRestrictions: true,
        allergies: true,
        favoriteCuisines: true,
        swipeActions: {
          select: {
            dishId: true,
            action: true,
            createdAt: true
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // ============================================================================
    // STEP 2: CONFIGURE ALGORITHM
    // ============================================================================
    // Validate and normalize scoring weights
    const validatedWeights = validateScoringWeights(scoring_weights)
    
    // Merge algorithm configuration
    const config = { ...DEFAULT_ALGORITHM_CONFIG, ...algorithm_config }

    // ============================================================================
    // STEP 3: CANDIDATE GENERATION
    // ============================================================================
    // Query nearby dishes within user's radius, excluding already swiped items
    // Prioritize recently added items and those with high ratings
    
    const swipedDishIds = user.swipeActions.map(action => action.dishId)
    
    // Base query for candidates
    const whereClause: any = {
      isActive: true,
      isAvailable: true,
      restaurant: {
        isActive: true
      }
    }

    // Exclude already swiped items
    if (swipedDishIds.length > 0) {
      whereClause.id = { notIn: swipedDishIds }
    }

    // Apply category filters if provided
    if (category_filters.length > 0) {
      whereClause.OR = category_filters.map(filter => ({
        cuisine: { contains: filter, mode: 'insensitive' }
      }))
    }

    // Apply user dietary restrictions as hard filters
    if (user.dietaryRestrictions.length > 0) {
      const allowedTags = user.dietaryRestrictions.map(dr => dr.type)
      whereClause.dishDietaryTags = {
        some: { tag: { in: allowedTags } }
      }
    }

    // Fetch candidates with all necessary data for scoring
    const candidates = await db.dish.findMany({
      where: whereClause,
      include: {
        restaurant: true,
        dishDietaryTags: true,
        reviews: true,
        _count: {
          select: {
            swipeActions: true
          }
        }
      },
      orderBy: [
        { createdAt: 'desc' } // Prioritize recent items
      ],
      take: limit * 3 // Fetch 3x more candidates for scoring and exploration
    })

    // ============================================================================
    // STEP 4: FILTER BY DISTANCE
    // ============================================================================
    // Calculate distance and filter by user's search radius
    const candidatesWithinRadius = candidates.filter(candidate => {
      const distance = calculateDistance(
        latitude, longitude,
        candidate.restaurant.lat, candidate.restaurant.lng
      )
      return distance <= (user.searchRadius || config.maxRadiusKm)
    })

    // ============================================================================
    // STEP 5: SCORING ALGORITHM
    // ============================================================================
    // Compute scores for each candidate based on multiple factors
    
    const scoredCandidates: CandidateScore[] = []
    
    for (const candidate of candidatesWithinRadius) {
      const score = await computeCandidateScore(
        candidate, 
        user, 
        candidatesWithinRadius, 
        validatedWeights, 
        config
      )
      scoredCandidates.push(score)
    }

    // ============================================================================
    // STEP 6: EXPLORATION INJECTION
    // ============================================================================
    // Inject random/trending items to avoid filter bubbles
    const explorationCount = Math.floor(
      (scoredCandidates.length * exploration_quota) / 100
    )
    
    const finalRecommendations = injectExplorationItems(
      scoredCandidates,
      candidatesWithinRadius,
      explorationCount,
      config
    )

    // ============================================================================
    // STEP 7: FINAL ORDERING AND RESPONSE
    // ============================================================================
    // Sort by final score and return top N candidates
    
    finalRecommendations.sort((a, b) => b.finalScore - a.finalScore)
    const topRecommendations = finalRecommendations.slice(0, limit)

    // Transform candidates to response format
    const recommendations = topRecommendations.map(scoredCandidate => {
      const candidate = candidatesWithinRadius.find(c => c.id === scoredCandidate.candidateId)!
      return transformCandidateToResponse(candidate, latitude, longitude, scoredCandidate)
    })

    // Calculate metadata
    const metadata = {
      totalCandidates: candidatesWithinRadius.length,
      explorationItemsInjected: explorationCount,
      averageScore: topRecommendations.reduce((sum, r) => sum + r.scoreBreakdown.tasteMatch, 0) / topRecommendations.length,
      scoreDistribution: calculateScoreDistribution(topRecommendations),
      algorithmVersion: '1.0.0',
      scoringWeights: validatedWeights,
      algorithmConfig: config
    }

    const response: RecommendationResponse = {
      recommendations,
      metadata
    }

    return NextResponse.json(response)

  } catch (error) {
    console.error('Recommendation API Error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ============================================================================
// GET ENDPOINT - ALGORITHM STATUS AND CONFIGURATION
// ============================================================================

export async function GET() {
  try {
    // Get real dishes from database plus sample dishes for variety
    const dbDishes = await db.dish.findMany({
      where: {
        isActive: true,
        isAvailable: true,
        restaurant: {
          isActive: true
        }
      },
      include: {
        restaurant: true,
        dishDietaryTags: true,
        reviews: true,
        _count: {
          select: {
            swipeActions: true
          }
        }
      },
      orderBy: [
        { createdAt: 'desc' } // Prioritize recently added dishes
      ],
      take: 20 // Get up to 20 real dishes
    })

    // Transform database dishes to the expected format
    const formattedDbDishes = dbDishes.map(dish => {
      const avgRating = dish.reviews.length > 0
        ? dish.reviews.reduce((sum, review) => sum + review.rating, 0) / dish.reviews.length
        : Math.random() * 2 + 3 // Random rating between 3-5 for dishes without reviews

      return {
        id: dish.id,
        name: dish.name,
        description: dish.description || `Delicious ${dish.cuisine} dish prepared with care and expertise`,
        image: dish.image || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop&crop=center`,
        price: dish.price,
        cuisine: dish.cuisine,
        rating: parseFloat(avgRating.toFixed(1)),
        restaurant: {
          id: dish.restaurant.id,
          name: dish.restaurant.name,
          address: dish.restaurant.address,
          rating: parseFloat((Math.random() * 2 + 3).toFixed(1)) // Random restaurant rating
        },
        dietaryTags: dish.dishDietaryTags.map(tag => tag.tag)
      }
    })

    // If we don't have enough real dishes, supplement with sample dishes
    const sampleDishes = [
      {
        id: 'sample-1',
        name: 'Truffle Pasta',
        description: 'Creamy pasta with black truffle and parmesan cheese',
        image: 'https://images.unsplash.com/photo-1473093226795-af9932fe5856?w=400&h=300&fit=crop&crop=center',
        price: 24.99,
        cuisine: 'Italian',
        rating: 4.8,
        restaurant: {
          id: 'sample-restaurant-1',
          name: 'Bella Italia',
          address: '123 Main St, New York, NY',
          rating: 4.6
        },
        dietaryTags: ['vegetarian']
      },
      {
        id: 'sample-2',
        name: 'Spicy Tuna Roll',
        description: 'Fresh tuna with spicy mayo and cucumber',
        image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&h=300&fit=crop&crop=center',
        price: 16.99,
        cuisine: 'Japanese',
        rating: 4.6,
        restaurant: {
          id: 'sample-restaurant-2',
          name: 'Sakura Sushi',
          address: '456 Oak Ave, New York, NY',
          rating: 4.7
        },
        dietaryTags: ['gluten-free', 'dairy-free']
      },
      {
        id: 'sample-3',
        name: 'BBQ Bacon Burger',
        description: 'Juicy beef patty with crispy bacon and BBQ sauce',
        image: 'https://images.unsplash.com/photo-1568901346375-23c9d0a3172b?w=400&h=300&fit=crop&crop=center',
        price: 18.99,
        cuisine: 'American',
        rating: 4.5,
        restaurant: {
          id: 'sample-restaurant-3',
          name: 'The Grill House',
          address: '789 Elm St, New York, NY',
          rating: 4.4
        },
        dietaryTags: []
      }
    ]

    // Combine real dishes with sample dishes, prioritizing real dishes
    const allDishes = [...formattedDbDishes]
    
    // Add sample dishes if we need more variety
    if (allDishes.length < 10) {
      allDishes.push(...sampleDishes.slice(0, 10 - allDishes.length))
    }

    return NextResponse.json({
      dishes: allDishes.slice(0, 15), // Return up to 15 dishes
      status: 'active',
      version: '1.0.0',
      defaultWeights: DEFAULT_SCORING_WEIGHTS,
      defaultConfig: DEFAULT_ALGORITHM_CONFIG,
      supportedFeatures: [
        'taste_matching',
        'recency_boosting',
        'popularity_scoring',
        'diversity_boosting',
        'exploration_injection',
        'custom_weights',
        'algorithm_tuning'
      ],
      documentation: {
        tasteMatch: 'Matches user preferences (cuisines, dietary restrictions, price range)',
        recency: 'Boosts recently added items with decay function',
        popularity: 'Based on ratings and engagement metrics',
        diversity: 'Boosts underrepresented cuisines to prevent filter bubbles',
        exploration: 'Injects random items for serendipity'
      },
      stats: {
        totalDishes: allDishes.length,
        realDishes: formattedDbDishes.length,
        sampleDishes: Math.max(0, allDishes.length - formattedDbDishes.length)
      }
    })
  } catch (error) {
    console.error('Recommendation status error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Transform candidate database record to API response format
 */
function transformCandidateToResponse(
  candidate: any, 
  userLat: number, 
  userLng: number,
  scoreData?: CandidateScore
) {
  const distance = calculateDistance(userLat, userLng, candidate.restaurant.lat, candidate.restaurant.lng)
  const avgRating = candidate.reviews.length > 0
    ? candidate.reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / candidate.reviews.length
    : undefined

  return {
    id: candidate.id,
    type: 'dish',
    name: candidate.name,
    image: candidate.image,
    cuisine: candidate.cuisine,
    rating: avgRating,
    distance,
    description: candidate.description,
    price: candidate.price,
    priceRange: candidate.restaurant.priceRange,
    address: candidate.restaurant.address,
    dietaryTags: candidate.dishDietaryTags.map((tag: any) => tag.tag),
    restaurant: {
      id: candidate.restaurant.id,
      name: candidate.restaurant.name,
      address: candidate.restaurant.address,
      priceRange: candidate.restaurant.priceRange
    },
    scoring: scoreData ? {
      finalScore: scoreData.finalScore,
      breakdown: scoreData.scoreBreakdown
    } : undefined,
    metadata: {
      totalSwipes: candidate._count.swipeActions,
      reviewCount: candidate.reviews.length,
      createdAt: candidate.createdAt
    }
  }
}