import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const sampleDishes = [
  {
    name: "Classic Margherita Pizza",
    description: "Fresh mozzarella, basil, and tomato sauce on a crispy wood-fired crust",
    image: "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?w=400&h=400&fit=crop",
    price: 12.99,
    cuisine: "Italian",
    isActive: true,
    isAvailable: true
  },
  {
    name: "Spicy Thai Pad Thai",
    description: "Stir-fried rice noodles with shrimp, tofu, peanuts, and tangy tamarind sauce",
    image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&h=400&fit=crop",
    price: 14.99,
    cuisine: "Thai",
    isActive: true,
    isAvailable: true
  },
  {
    name: "Vegan Buddha Bowl",
    description: "Quinoa, roasted vegetables, avocado, and tahini dressing",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=400&fit=crop",
    price: 11.99,
    cuisine: "American",
    isActive: true,
    isAvailable: true
  },
  {
    name: "Japanese Ramen",
    description: "Rich tonkotsu broth with chashu pork, soft-boiled egg, and fresh noodles",
    image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&h=400&fit=crop",
    price: 15.99,
    cuisine: "Japanese",
    isActive: true,
    isAvailable: true
  },
  {
    name: "Mexican Street Tacos",
    description: "Three corn tortillas with seasoned beef, cilantro, onions, and lime",
    image: "https://images.unsplash.com/photo-1551504734-5ee1c4a8e0c4?w=400&h=400&fit=crop",
    price: 9.99,
    cuisine: "Mexican",
    isActive: true,
    isAvailable: true
  }
]

const sampleRestaurants = [
  {
    name: "Bella Italia Trattoria",
    description: "Authentic Italian cuisine in a cozy atmosphere",
    address: "123 Main St, New York, NY",
    lat: 40.7128,
    lng: -74.0060,
    phone: "(555) 123-4567",
    priceRange: "medium",
    isActive: true
  },
  {
    name: "Thai Spice Garden",
    description: "Traditional Thai flavors with modern twists",
    address: "456 Oak Ave, New York, NY",
    lat: 40.7580,
    lng: -73.9855,
    phone: "(555) 234-5678",
    priceRange: "low",
    isActive: true
  },
  {
    name: "Green Garden Café",
    description: "Fresh, healthy, and delicious plant-based options",
    address: "789 Elm St, New York, NY",
    lat: 40.7489,
    lng: -73.9680,
    phone: "(555) 345-6789",
    priceRange: "low",
    isActive: true
  }
]

export async function POST(request: NextRequest) {
  try {
    // Create restaurants first
    const createdRestaurants = []
    for (const restaurant of sampleRestaurants) {
      const created = await db.restaurant.create({
        data: restaurant
      })
      createdRestaurants.push(created)
    }

    // Create dishes and associate with restaurants
    for (let i = 0; i < sampleDishes.length; i++) {
      const dish = sampleDishes[i]
      const restaurant = createdRestaurants[i % createdRestaurants.length]
      
      await db.dish.create({
        data: {
          ...dish,
          restaurantId: restaurant.id,
          dishDietaryTags: {
            create: dish.name.toLowerCase().includes('vegan') 
              ? [{ tag: 'vegan' }, { tag: 'gluten-free' }]
              : []
          }
        }
      })
    }

    return NextResponse.json({
      message: 'Sample data created successfully',
      restaurants: createdRestaurants.length,
      dishes: sampleDishes.length
    })

  } catch (error) {
    console.error('Seed data error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}