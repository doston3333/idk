import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const { referralCode, userId } = await request.json();

    if (!referralCode || !userId) {
      return NextResponse.json({ 
        error: 'Referral code and user ID are required' 
      }, { status: 400 });
    }

    // Find the referral code
    const referral = await db.referralCode.findFirst({
      where: { 
        code: referralCode.toUpperCase(),
        isActive: true 
      }
    });

    if (!referral) {
      return NextResponse.json({ error: 'Invalid referral code' }, { status: 404 });
    }

    // Check if referral code has expired
    if (referral.expiresAt && new Date() > referral.expiresAt) {
      return NextResponse.json({ error: 'Referral code has expired' }, { status: 400 });
    }

    // Check if max uses reached
    if (referral.currentUses >= referral.maxUses) {
      return NextResponse.json({ error: 'Referral code has reached maximum uses' }, { status: 400 });
    }

    // Check if user already has a coupon from this referral
    const existingCoupon = await db.coupon.findFirst({
      where: {
        userId,
        referralCodeId: referral.id
      }
    });

    if (existingCoupon) {
      return NextResponse.json({ 
        error: 'You have already used this referral code' 
      }, { status: 400 });
    }

    // Generate coupon code
    const couponCode = `WELCOME${nanoid(6).toUpperCase()}`;
    
    // Create coupon for the user
    const coupon = await db.coupon.create({
      data: {
        code: couponCode,
        userId,
        referralCodeId: referral.id,
        discountAmount: referral.discountAmount,
        discountType: referral.discountType,
        minOrderAmount: 15.00,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      }
    });

    // Update referral usage count
    await db.referralCode.update({
      where: { id: referral.id },
      data: { currentUses: referral.currentUses + 1 }
    });

    // Track analytics event
    await db.analyticsEvent.create({
      data: {
        userId,
        eventType: 'referral_applied',
        eventName: 'Referral Code Applied',
        properties: JSON.stringify({ 
          referralCode,
          couponCode,
          discountAmount: referral.discountAmount 
        }),
        value: referral.discountAmount,
      }
    });

    return NextResponse.json({
      coupon: {
        code: coupon.code,
        discountAmount: coupon.discountAmount,
        discountType: coupon.discountType,
        minOrderAmount: coupon.minOrderAmount,
        expiresAt: coupon.expiresAt
      },
      message: 'Coupon created successfully! Use it on your first order.'
    });

  } catch (error) {
    console.error('Error applying referral code:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}