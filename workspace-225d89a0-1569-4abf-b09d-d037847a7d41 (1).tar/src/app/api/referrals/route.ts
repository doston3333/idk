import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json();

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    // Check if user already has a referral code
    const existingReferral = await db.referralCode.findFirst({
      where: { referrerId: userId }
    });

    if (existingReferral) {
      return NextResponse.json({ 
        referralCode: existingReferral.code,
        message: 'Referral code already exists'
      });
    }

    // Generate new referral code
    const code = `FOODIE${nanoid(8).toUpperCase()}`;
    
    const referralCode = await db.referralCode.create({
      data: {
        code,
        referrerId: userId,
        discountAmount: 10.00,
        discountType: 'fixed',
        maxUses: 50,
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days
      }
    });

    // Track analytics event
    await db.analyticsEvent.create({
      data: {
        userId,
        eventType: 'referral_created',
        eventName: 'Referral Code Generated',
        properties: JSON.stringify({ referralCode: code }),
      }
    });

    return NextResponse.json({ 
      referralCode: referralCode.code,
      message: 'Referral code created successfully'
    });

  } catch (error) {
    console.error('Error creating referral code:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const referralCode = await db.referralCode.findFirst({
      where: { referrerId: userId, isActive: true },
      include: {
        referrer: {
          select: { name: true, email: true }
        }
      }
    });

    if (!referralCode) {
      return NextResponse.json({ error: 'No active referral code found' }, { status: 404 });
    }

    // Get referral stats
    const totalCoupons = await db.coupon.count({
      where: { referralCodeId: referralCode.id }
    });

    const usedCoupons = await db.coupon.count({
      where: { 
        referralCodeId: referralCode.id,
        isUsed: true 
      }
    });

    return NextResponse.json({
      referralCode: referralCode.code,
      discountAmount: referralCode.discountAmount,
      discountType: referralCode.discountType,
      currentUses: referralCode.currentUses,
      maxUses: referralCode.maxUses,
      expiresAt: referralCode.expiresAt,
      stats: {
        totalGenerated: totalCoupons,
        totalUsed: usedCoupons,
        conversionRate: totalCoupons > 0 ? (usedCoupons / totalCoupons) * 100 : 0
      }
    });

  } catch (error) {
    console.error('Error fetching referral code:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}