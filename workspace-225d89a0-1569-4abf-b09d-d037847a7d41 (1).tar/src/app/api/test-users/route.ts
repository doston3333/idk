import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const users = await db.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        onboardingCompleted: true,
        role: true,
        createdAt: true
      }
    })

    return NextResponse.json({ users })
  } catch (error) {
    console.error('Error fetching users:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST() {
  try {
    // Create a test user with completed onboarding
    const testUser = await db.user.create({
      data: {
        email: 'dashboard@test.com',
        name: 'Dashboard Test User',
        onboardingCompleted: true,
        role: 'user',
        emailVerified: true,
        subscriptionTier: 'free'
      }
    })

    return NextResponse.json({
      message: 'Test user created successfully',
      user: {
        id: testUser.id,
        email: testUser.email,
        name: testUser.name,
        onboardingCompleted: testUser.onboardingCompleted
      }
    })
  } catch (error) {
    console.error('Error creating test user:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}