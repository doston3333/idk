'use client'

import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Loader2, Calendar as CalendarIcon, Clock, Users, MapPin } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { format } from 'date-fns'

interface Restaurant {
  id: string
  name: string
  address: string
  phone?: string
  priceRange: string
  image?: string
}

interface TimeSlot {
  time: string
  available: boolean
}

interface ReservationModalProps {
  restaurant: Restaurant
  isOpen: boolean
  onClose: () => void
  userId?: string
}

export function ReservationModal({ restaurant, isOpen, onClose, userId }: ReservationModalProps) {
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [selectedTime, setSelectedTime] = useState<string>('')
  const [partySize, setPartySize] = useState<number>(2)
  const [specialNotes, setSpecialNotes] = useState('')
  const [availableTimes, setAvailableTimes] = useState<TimeSlot[]>([])
  const [isLoadingTimes, setIsLoadingTimes] = useState(false)
  const [isMakingReservation, setIsMakingReservation] = useState(false)
  const { toast } = useToast()

  // Generate time slots when date is selected
  useEffect(() => {
    if (selectedDate) {
      fetchAvailableTimes()
    }
  }, [selectedDate])

  const fetchAvailableTimes = async () => {
    if (!selectedDate) return

    setIsLoadingTimes(true)
    try {
      // Mock time slots - in real app, this would call restaurant booking API
      const mockTimes: TimeSlot[] = [
        { time: '11:30', available: true },
        { time: '12:00', available: true },
        { time: '12:30', available: false },
        { time: '13:00', available: true },
        { time: '13:30', available: true },
        { time: '14:00', available: true },
        { time: '17:30', available: true },
        { time: '18:00', available: false },
        { time: '18:30', available: true },
        { time: '19:00', available: true },
        { time: '19:30', available: true },
        { time: '20:00', available: true },
        { time: '20:30', available: true },
        { time: '21:00', available: false },
      ]
      setAvailableTimes(mockTimes)
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load available times',
        variant: 'destructive'
      })
    } finally {
      setIsLoadingTimes(false)
    }
  }

  const handleMakeReservation = async () => {
    if (!userId) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to make a reservation',
        variant: 'destructive'
      })
      return
    }

    if (!selectedDate) {
      toast({
        title: 'Date Required',
        description: 'Please select a date for your reservation',
        variant: 'destructive'
      })
      return
    }

    if (!selectedTime) {
      toast({
        title: 'Time Required',
        description: 'Please select a time for your reservation',
        variant: 'destructive'
      })
      return
    }

    setIsMakingReservation(true)
    try {
      // Combine date and time
      const reservationDateTime = new Date(selectedDate)
      const [hours, minutes] = selectedTime.split(':')
      reservationDateTime.setHours(parseInt(hours), parseInt(minutes))

      const response = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          restaurantId: restaurant.id,
          date: reservationDateTime.toISOString(),
          partySize,
          specialNotes
        })
      })

      if (response.ok) {
        const reservation = await response.json()
        toast({
          title: 'Reservation Confirmed!',
          description: `Your table for ${partySize} at ${selectedTime} on ${format(selectedDate, 'MMM d, yyyy')} has been reserved.`
        })
        onClose()
        
        // In a real app, redirect to reservation details or send confirmation
        console.log('Reservation created:', reservation)
      } else {
        throw new Error('Failed to make reservation')
      }
    } catch (error) {
      toast({
        title: 'Reservation Failed',
        description: 'There was an error making your reservation. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setIsMakingReservation(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">Make a Reservation</CardTitle>
              <p className="text-muted-foreground mt-1">{restaurant.name}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Restaurant Details */}
          <div className="flex gap-4">
            {restaurant.image && (
              <img 
                src={restaurant.image} 
                alt={restaurant.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <h3 className="font-semibold">{restaurant.name}</h3>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {restaurant.address}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary">{restaurant.priceRange}</Badge>
                {restaurant.phone && (
                  <span className="text-sm text-muted-foreground">{restaurant.phone}</span>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Date Selection */}
          <div className="space-y-2">
            <Label>Select Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={(date) => date < new Date() || date < new Date(new Date().setHours(0,0,0,0))}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Time Selection */}
          <div className="space-y-3">
            <Label>Select Time</Label>
            {selectedDate ? (
              isLoadingTimes ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span className="ml-2">Loading available times...</span>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-2">
                  {availableTimes.map((slot) => (
                    <Button
                      key={slot.time}
                      variant={selectedTime === slot.time ? "default" : "outline"}
                      size="sm"
                      disabled={!slot.available}
                      onClick={() => setSelectedTime(slot.time)}
                      className="text-sm"
                    >
                      {slot.time}
                      {!slot.available && (
                        <span className="ml-1 text-xs">(Full)</span>
                      )}
                    </Button>
                  ))}
                </div>
              )
            ) : (
              <p className="text-sm text-muted-foreground">Please select a date first</p>
            )}
          </div>

          {/* Party Size */}
          <div className="space-y-2">
            <Label htmlFor="party-size">Party Size</Label>
            <Select value={partySize.toString()} onValueChange={(value) => setPartySize(parseInt(value))}>
              <SelectTrigger>
                <SelectValue placeholder="Select party size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 person</SelectItem>
                <SelectItem value="2">2 people</SelectItem>
                <SelectItem value="3">3 people</SelectItem>
                <SelectItem value="4">4 people</SelectItem>
                <SelectItem value="5">5 people</SelectItem>
                <SelectItem value="6">6 people</SelectItem>
                <SelectItem value="7">7 people</SelectItem>
                <SelectItem value="8">8 people</SelectItem>
                <SelectItem value="9">9 people</SelectItem>
                <SelectItem value="10">10+ people</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Special Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Special Requests (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any special requests or dietary restrictions..."
              value={specialNotes}
              onChange={(e) => setSpecialNotes(e.target.value)}
              rows={3}
            />
          </div>

          <Separator />

          {/* Reservation Summary */}
          <div className="space-y-2">
            <h4 className="font-semibold">Reservation Summary</h4>
            <div className="space-y-1 text-sm bg-muted/50 p-3 rounded-lg">
              <div className="flex justify-between">
                <span>Restaurant:</span>
                <span className="font-medium">{restaurant.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span className="font-medium">
                  {selectedDate ? format(selectedDate, 'EEEE, MMMM d, yyyy') : 'Not selected'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Time:</span>
                <span className="font-medium">{selectedTime || 'Not selected'}</span>
              </div>
              <div className="flex justify-between">
                <span>Party Size:</span>
                <span className="font-medium">{partySize} {partySize === 1 ? 'person' : 'people'}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="flex-1"
              disabled={isMakingReservation}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleMakeReservation}
              className="flex-1"
              disabled={isMakingReservation || !selectedDate || !selectedTime}
            >
              {isMakingReservation ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Making Reservation...
                </>
              ) : (
                <>
                  <Clock className="h-4 w-4 mr-2" />
                  Confirm Reservation
                </>
              )}
            </Button>
          </div>

          {/* Cancellation Policy */}
          <div className="text-center text-xs text-muted-foreground">
            <p>Free cancellation up to 2 hours before reservation time</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}