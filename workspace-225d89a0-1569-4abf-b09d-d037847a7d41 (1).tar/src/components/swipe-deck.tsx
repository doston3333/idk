'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { motion, AnimatePresence, PanInfo, useAnimation } from 'framer-motion'
import { 
  X, 
  Heart, 
  Star, 
  MapPin, 
  DollarSign, 
  Clock,
  Sparkles,
  Utensils,
  Zap,
  Flame
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'
import Image from 'next/image'

interface Candidate {
  id: string
  type: 'dish' | 'restaurant'
  name: string
  image: string
  cuisine: string
  rating?: number
  distance?: number
  description?: string
  price?: number
  priceRange?: string
  address?: string
  dietaryTags: string[]
  restaurant?: {
    id: string
    name: string
    address: string
    priceRange: string
  }
}

interface SwipeDeckProps {
  candidates: Candidate[]
  onSwipe: (candidateId: string, action: 'like' | 'pass' | 'super_like') => void
  onLoadMore: () => void
  isLoading: boolean
  remainingSwipes: number
  maxDailySwipes: number
  superLikesRemaining: number
  subscriptionTier: string
}

const SWIPE_THRESHOLD = 80
const SUPER_LIKE_THRESHOLD = 120
const SPRING_CONFIG = { type: "spring", stiffness: 400, damping: 25 }
const EXIT_SPRING = { type: "spring", stiffness: 300, damping: 30 }

export default function SwipeDeck({
  candidates,
  onSwipe,
  onLoadMore,
  isLoading,
  remainingSwipes,
  maxDailySwipes,
  superLikesRemaining,
  subscriptionTier
}: SwipeDeckProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [dragDirection, setDragDirection] = useState<'left' | 'right' | 'up' | null>(null)
  const [showMatch, setShowMatch] = useState(false)
  const [matchedDish, setMatchedDish] = useState<Candidate | null>(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0, rotate: 0 })
  const [showPulse, setShowPulse] = useState(false)
  
  const controls = useAnimation()
  const currentCandidate = candidates[currentIndex]
  const canSwipe = maxDailySwipes === -1 || remainingSwipes > 0

  // Calculate swipe progress for visual feedback
  const getSwipeProgress = useCallback(() => {
    const progress = Math.min(Math.abs(dragOffset.x) / SWIPE_THRESHOLD, 1)
    return progress
  }, [dragOffset.x])

  // Get rotation based on drag position
  const getRotation = useCallback((x: number) => {
    return x * 0.05 // Subtle rotation based on horizontal position
  }, [])

  // Get scale based on drag velocity
  const getScale = useCallback((velocity: number) => {
    return Math.min(1 + Math.abs(velocity) * 0.0001, 1.1)
  }, [])

  const handleDrag = useCallback((event: any, info: PanInfo) => {
    const { offset, velocity } = info
    
    if (Math.abs(offset.x) > 5 || Math.abs(offset.y) > 5) {
      setIsDragging(true)
    }

    // Update drag offset for real-time visual feedback
    setDragOffset({ 
      x: offset.x, 
      y: offset.y, 
      rotate: getRotation(offset.x) 
    })

    // Determine swipe direction
    if (Math.abs(offset.x) > Math.abs(offset.y)) {
      setDragDirection(offset.x > 0 ? 'right' : 'left')
    } else if (offset.y < -50) {
      setDragDirection('up')
    }

    // Add haptic-like feedback at thresholds
    const progress = getSwipeProgress()
    if (progress > 0.7 && !showPulse) {
      setShowPulse(true)
      setTimeout(() => setShowPulse(false), 200)
    }
  }, [getRotation, getSwipeProgress, showPulse])

  const handleDragEnd = useCallback(async (event: any, info: PanInfo) => {
    const { offset, velocity } = info
    setIsDragging(false)
    setDragDirection(null)
    setDragOffset({ x: 0, y: 0, rotate: 0 })

    if (!currentCandidate || !canSwipe) return

    let swipeAction: 'like' | 'pass' | 'super_like' | null = null

    // Enhanced threshold detection with velocity consideration
    const horizontalForce = Math.abs(offset.x) + Math.abs(velocity.x) * 0.1
    const verticalForce = Math.abs(offset.y) + Math.abs(velocity.y) * 0.1

    if (horizontalForce > SWIPE_THRESHOLD) {
      swipeAction = offset.x > 0 ? 'like' : 'pass'
    } else if (offset.y < -SUPER_LIKE_THRESHOLD || velocity.y < -300) {
      swipeAction = 'super_like'
    }

    if (swipeAction) {
      // Check super like limits
      if (swipeAction === 'super_like' && subscriptionTier === 'free') {
        toast.error('Super likes are only available for premium users!')
        // Animate card back to center
        controls.start({ x: 0, y: 0, rotate: 0, transition: SPRING_CONFIG })
        return
      }

      if (swipeAction === 'super_like' && superLikesRemaining <= 0) {
        toast.error('No super likes remaining!')
        controls.start({ x: 0, y: 0, rotate: 0, transition: SPRING_CONFIG })
        return
      }

      await performSwipe(currentCandidate.id, swipeAction, info)
    } else {
      // Animate back to center with spring physics
      controls.start({ x: 0, y: 0, rotate: 0, transition: SPRING_CONFIG })
    }
  }, [currentCandidate, canSwipe, subscriptionTier, superLikesRemaining, controls])

  const performSwipe = async (candidateId: string, action: 'like' | 'pass' | 'super_like', dragInfo?: PanInfo) => {
    try {
      // Animate card out with enhanced physics
      const exitX = action === 'like' ? 400 : action === 'pass' ? -400 : 0
      const exitY = action === 'super_like' ? -400 : 0
      const exitRotate = action === 'like' ? 25 : action === 'pass' ? -25 : 0

      await controls.start({
        x: exitX,
        y: exitY,
        rotate: exitRotate,
        scale: 0.8,
        opacity: 0,
        transition: { ...EXIT_SPRING, duration: 0.4 }
      })

      const result = await onSwipe(candidateId, action)
      
      if (result?.match) {
        setMatchedDish(currentCandidate)
        setShowMatch(true)
        setTimeout(() => setShowMatch(false), 3000)
      }

      setCurrentIndex(prev => prev + 1)
      
      // Load more candidates when we're running low
      if (currentIndex >= candidates.length - 3) {
        onLoadMore()
      }

      // Reset controls for next card
      controls.set({ x: 0, y: 0, rotate: 0, scale: 1, opacity: 1 })
    } catch (error) {
      console.error('Swipe failed:', error)
      toast.error('Failed to save swipe')
      controls.start({ x: 0, y: 0, rotate: 0, transition: SPRING_CONFIG })
    }
  }

  const handleButtonClick = async (action: 'like' | 'pass' | 'super_like') => {
    if (!currentCandidate || !canSwipe) return

    if (action === 'super_like' && subscriptionTier === 'free') {
      toast.error('Super likes are only available for premium users!')
      return
    }

    if (action === 'super_like' && superLikesRemaining <= 0) {
      toast.error('No super likes remaining!')
      return
    }

    // Create mock drag info for animation
    const mockDragInfo: PanInfo = {
      offset: { x: action === 'like' ? 200 : action === 'pass' ? -200 : 0, y: action === 'super_like' ? -200 : 0 },
      velocity: { x: action === 'like' ? 1000 : action === 'pass' ? -1000 : 0, y: action === 'super_like' ? -1000 : 0 }
    }

    await performSwipe(currentCandidate.id, action, mockDragInfo)
  }

  const getPriceRangeSymbol = (range?: string) => {
    switch (range) {
      case 'low': return '$'
      case 'medium': return '$$'
      case 'high': return '$$$'
      default: return '$'
    }
  }

  const formatDistance = (distance?: number) => {
    if (!distance) return ''
    if (distance < 1) return `${Math.round(distance * 1000)}m`
    return `${Math.round(distance)}km`
  }

  if (!currentCandidate && !isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Utensils className="h-16 w-16 text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No more dishes!</h3>
          <p className="text-gray-500 mb-4">Check back later for more delicious options</p>
          <Button onClick={onLoadMore} disabled={isLoading}>
            {isLoading ? 'Loading...' : 'Refresh'}
          </Button>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Enhanced Match Animation */}
      <AnimatePresence>
        {showMatch && matchedDish && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 rounded-2xl backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.3, rotate: -10 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0.3, rotate: 10 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="text-center text-white"
            >
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.1, type: "spring", stiffness: 400 }}
                className="text-8xl mb-4"
              >
                🎉
              </motion.div>
              <motion.h2
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3, type: "spring", stiffness: 300 }}
                className="text-4xl font-bold mb-2"
              >
                It's a Match!
              </motion.h2>
              <motion.p
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5, type: "spring", stiffness: 300 }}
                className="text-xl"
              >
                You both liked {matchedDish.name}
              </motion.p>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.7, type: "spring", stiffness: 400 }}
                className="mt-4"
              >
                <Flame className="h-8 w-8 mx-auto text-orange-400" />
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Swipe Limits Notice */}
      {!canSwipe && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-4 left-4 right-4 z-40 bg-yellow-50 border border-yellow-200 rounded-lg p-4"
        >
          <div className="flex items-center">
            <Clock className="h-5 w-5 text-yellow-600 mr-2" />
            <div>
              <p className="text-sm font-medium text-yellow-800">
                Daily swipe limit reached
              </p>
              <p className="text-xs text-yellow-600">
                Upgrade to premium for unlimited swipes
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Super Likes Counter */}
      {subscriptionTier !== 'free' && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="absolute top-4 right-4 z-40 bg-blue-50 border border-blue-200 rounded-lg p-3"
        >
          <div className="flex items-center">
            <Sparkles className="h-4 w-4 text-blue-600 mr-2" />
            <span className="text-sm font-medium text-blue-800">
              {superLikesRemaining} Super Likes
            </span>
          </div>
        </motion.div>
      )}

      {/* Enhanced Cards Stack */}
      <div className="relative flex-1 flex items-center justify-center">
        <div className="relative w-full max-w-sm h-[600px]">
          {/* Enhanced Background Cards with Preview */}
          {candidates.slice(currentIndex + 1, currentIndex + 4).map((candidate, index) => (
            <motion.div
              key={candidate.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{
                scale: 1 - (index + 1) * 0.08,
                y: (index + 1) * 15,
                opacity: 1 - (index + 1) * 0.3,
                rotate: (index + 1) * 2
              }}
              transition={{
                type: "spring",
                stiffness: 300,
                damping: 25,
                delay: index * 0.05
              }}
              className="absolute inset-0 rounded-2xl bg-gray-100 shadow-lg"
              style={{
                zIndex: 10 - index
              }}
            >
              <div className="w-full h-full rounded-2xl bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                <div className="text-center text-gray-400">
                  <Utensils className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-sm font-medium">{candidate.name}</p>
                </div>
              </div>
            </motion.div>
          ))}

          {/* Enhanced Current Card */}
          <AnimatePresence>
            {currentCandidate && (
              <motion.div
                key={currentCandidate.id}
                drag
                dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
                dragElastic={0.15}
                dragMomentum={false}
                onDrag={handleDrag}
                onDragEnd={handleDragEnd}
                animate={controls}
                style={{
                  x: dragOffset.x,
                  y: dragOffset.y,
                  rotate: dragOffset.rotate,
                  scale: isDragging ? 1.02 : 1
                }}
                transition={SPRING_CONFIG}
                className="absolute inset-0 z-20"
              >
                <Card className="w-full h-full rounded-2xl overflow-hidden shadow-2xl border-0">
                  <div className="relative h-full">
                    {/* Enhanced Image with Parallax */}
                    <div className="relative h-3/5">
                      <motion.div
                        animate={{
                          scale: isDragging ? 1.05 : 1,
                        }}
                        transition={{ duration: 0.2 }}
                        className="relative w-full h-full"
                      >
                        <Image
                          src={currentCandidate.image}
                          alt={currentCandidate.name}
                          fill
                          className="object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement
                            const cuisine = currentCandidate.cuisine?.toLowerCase() || 'food'
                            target.src = `/api/placeholder/400/300/${cuisine}`
                          }}
                        />
                      </motion.div>
                      
                      {/* Enhanced Overlay Gradient */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                      
                      {/* Progressive Swipe Indicators */}
                      <AnimatePresence>
                        {isDragging && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-0 flex items-center justify-center"
                          >
                            {/* Like Indicator */}
                            {dragDirection === 'right' && (
                              <motion.div
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ 
                                  scale: 0.8 + getSwipeProgress() * 0.4,
                                  opacity: 0.7 + getSwipeProgress() * 0.3
                                }}
                                className="absolute inset-0 flex items-center justify-center"
                              >
                                <div className="bg-green-500 text-white px-8 py-4 rounded-full font-bold text-2xl shadow-2xl">
                                  <Heart className="inline h-8 w-8 mr-3" />
                                  LIKE
                                </div>
                              </motion.div>
                            )}
                            
                            {/* Pass Indicator */}
                            {dragDirection === 'left' && (
                              <motion.div
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ 
                                  scale: 0.8 + getSwipeProgress() * 0.4,
                                  opacity: 0.7 + getSwipeProgress() * 0.3
                                }}
                                className="absolute inset-0 flex items-center justify-center"
                              >
                                <div className="bg-red-500 text-white px-8 py-4 rounded-full font-bold text-2xl shadow-2xl">
                                  <X className="inline h-8 w-8 mr-3" />
                                  PASS
                                </div>
                              </motion.div>
                            )}
                            
                            {/* Super Like Indicator */}
                            {dragDirection === 'up' && (
                              <motion.div
                                initial={{ scale: 0.5, opacity: 0 }}
                                animate={{ 
                                  scale: 0.8 + getSwipeProgress() * 0.4,
                                  opacity: 0.7 + getSwipeProgress() * 0.3
                                }}
                                className="absolute inset-0 flex items-center justify-center"
                              >
                                <div className="bg-blue-500 text-white px-8 py-4 rounded-full font-bold text-2xl shadow-2xl">
                                  <Star className="inline h-8 w-8 mr-3" />
                                  SUPER LIKE
                                </div>
                              </motion.div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Threshold Glow Effects */}
                      <AnimatePresence>
                        {showPulse && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: [0, 0.6, 0] }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.6 }}
                            className={`absolute inset-0 rounded-2xl ${
                              dragDirection === 'right' ? 'bg-green-400' :
                              dragDirection === 'left' ? 'bg-red-400' :
                              'bg-blue-400'
                            } mix-blend-overlay`}
                          />
                        )}
                      </AnimatePresence>

                      {/* Enhanced Top Info */}
                      <motion.div 
                        className="absolute top-4 left-4 right-4"
                        animate={{ y: isDragging ? -2 : 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <Badge variant="secondary" className="bg-white/95 text-black backdrop-blur-sm shadow-lg">
                              {currentCandidate.cuisine}
                            </Badge>
                          </div>
                          {currentCandidate.rating && (
                            <motion.div 
                              className="bg-white/95 backdrop-blur px-3 py-1.5 rounded-full flex items-center shadow-lg"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <Star className="h-4 w-4 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium ml-1">
                                {currentCandidate.rating.toFixed(1)}
                              </span>
                            </motion.div>
                          )}
                        </div>
                      </motion.div>
                    </div>

                    {/* Enhanced Content */}
                    <motion.div 
                      className="absolute bottom-0 left-0 right-0 bg-white p-4"
                      animate={{ y: isDragging ? 2 : 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">
                            {currentCandidate.name}
                          </h3>
                          {currentCandidate.restaurant && (
                            <p className="text-sm text-gray-600">
                              {currentCandidate.restaurant.name}
                            </p>
                          )}
                        </div>
                        <div className="text-right">
                          {currentCandidate.price && (
                            <div className="flex items-center text-green-600 font-bold">
                              <DollarSign className="h-4 w-4" />
                              {currentCandidate.price.toFixed(2)}
                            </div>
                          )}
                          <div className="text-sm text-gray-500">
                            {getPriceRangeSymbol(currentCandidate.priceRange)}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                        {currentCandidate.distance && (
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {formatDistance(currentCandidate.distance)}
                          </div>
                        )}
                      </div>

                      {currentCandidate.dietaryTags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {currentCandidate.dietaryTags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {currentCandidate.dietaryTags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{currentCandidate.dietaryTags.length - 3}
                            </Badge>
                          )}
                        </div>
                      )}
                    </motion.div>
                  </div>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Enhanced Action Buttons */}
      <motion.div 
        className="flex justify-center items-center gap-4 py-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="lg"
            onClick={() => handleButtonClick('pass')}
            disabled={!canSwipe || !currentCandidate}
            className="rounded-full h-16 w-16 p-0 border-red-200 hover:border-red-400 hover:bg-red-50 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <X className="h-8 w-8 text-red-500" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="lg"
            onClick={() => handleButtonClick('super_like')}
            disabled={!canSwipe || !currentCandidate || subscriptionTier === 'free' || superLikesRemaining <= 0}
            className="rounded-full h-14 w-14 p-0 border-blue-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Star className="h-6 w-6 text-blue-500" />
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
          <Button
            variant="outline"
            size="lg"
            onClick={() => handleButtonClick('like')}
            disabled={!canSwipe || !currentCandidate}
            className="rounded-full h-16 w-16 p-0 border-green-200 hover:border-green-400 hover:bg-green-50 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Heart className="h-8 w-8 text-green-500" />
          </Button>
        </motion.div>
      </motion.div>
    </div>
  )
}