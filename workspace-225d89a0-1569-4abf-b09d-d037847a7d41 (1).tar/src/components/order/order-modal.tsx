'use client'

import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Loader2, Clock, MapPin, CreditCard, Truck } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Dish {
  id: string
  name: string
  price: number
  image: string
  description?: string
  restaurant: {
    id: string
    name: string
    address: string
    priceRange: string
  }
}

interface DeliveryOption {
  id: string
  name: string
  estimatedTime: number
  fee: number
  logo: string
}

interface OrderModalProps {
  dish: Dish
  isOpen: boolean
  onClose: () => void
  userId?: string
}

export function OrderModal({ dish, isOpen, onClose, userId }: OrderModalProps) {
  const [quantity, setQuantity] = useState(1)
  const [deliveryAddress, setDeliveryAddress] = useState('')
  const [specialNotes, setSpecialNotes] = useState('')
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryOption | null>(null)
  const [deliveryOptions, setDeliveryOptions] = useState<DeliveryOption[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isPlacingOrder, setIsPlacingOrder] = useState(false)
  const { toast } = useToast()

  // Calculate total cost
  const subtotal = dish.price * quantity
  const deliveryFee = selectedDelivery?.fee || 0
  const total = subtotal + deliveryFee

  // Fetch delivery options when modal opens
  useEffect(() => {
    if (isOpen && dish.restaurant) {
      fetchDeliveryOptions()
    }
  }, [isOpen, dish.restaurant])

  const fetchDeliveryOptions = async () => {
    setIsLoading(true)
    try {
      // Mock delivery options - in real app, this would call delivery APIs
      const mockOptions: DeliveryOption[] = [
        {
          id: 'uber_eats',
          name: 'Uber Eats',
          estimatedTime: 25,
          fee: 2.99,
          logo: '🛵'
        },
        {
          id: 'door_dash',
          name: 'DoorDash',
          estimatedTime: 30,
          fee: 1.99,
          logo: '🚗'
        },
        {
          id: 'grubhub',
          name: 'Grubhub',
          estimatedTime: 35,
          fee: 3.49,
          logo: '🥡'
        }
      ]
      setDeliveryOptions(mockOptions)
      setSelectedDelivery(mockOptions[0]) // Select first option by default
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load delivery options',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePlaceOrder = async () => {
    if (!userId) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to place an order',
        variant: 'destructive'
      })
      return
    }

    if (!deliveryAddress.trim()) {
      toast({
        title: 'Delivery Address Required',
        description: 'Please enter your delivery address',
        variant: 'destructive'
      })
      return
    }

    if (!selectedDelivery) {
      toast({
        title: 'Delivery Option Required',
        description: 'Please select a delivery option',
        variant: 'destructive'
      })
      return
    }

    setIsPlacingOrder(true)
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          restaurantId: dish.restaurant.id,
          dishId: dish.id,
          quantity,
          deliveryAddress,
          specialNotes,
          deliveryOption: selectedDelivery,
          totalAmount: total
        })
      })

      if (response.ok) {
        const order = await response.json()
        toast({
          title: 'Order Placed Successfully!',
          description: `Your order will arrive in approximately ${selectedDelivery.estimatedTime} minutes`
        })
        onClose()
        
        // In a real app, redirect to payment or order tracking
        console.log('Order created:', order)
      } else {
        throw new Error('Failed to place order')
      }
    } catch (error) {
      toast({
        title: 'Order Failed',
        description: 'There was an error placing your order. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setIsPlacingOrder(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">Place Order</CardTitle>
              <p className="text-muted-foreground mt-1">{dish.restaurant.name}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Dish Details */}
          <div className="flex gap-4">
            <img 
              src={dish.image} 
              alt={dish.name}
              className="w-20 h-20 rounded-lg object-cover"
            />
            <div className="flex-1">
              <h3 className="font-semibold">{dish.name}</h3>
              <p className="text-sm text-muted-foreground">{dish.description}</p>
              <p className="font-semibold text-primary">${dish.price.toFixed(2)}</p>
            </div>
          </div>

          <Separator />

          {/* Quantity Selection */}
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity</Label>
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                -
              </Button>
              <span className="w-12 text-center font-medium">{quantity}</span>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setQuantity(quantity + 1)}
              >
                +
              </Button>
            </div>
          </div>

          {/* Delivery Options */}
          <div className="space-y-3">
            <Label>Delivery Options</Label>
            {isLoading ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span className="ml-2">Loading delivery options...</span>
              </div>
            ) : (
              <div className="space-y-2">
                {deliveryOptions.map((option) => (
                  <Card 
                    key={option.id}
                    className={`cursor-pointer transition-colors ${
                      selectedDelivery?.id === option.id 
                        ? 'ring-2 ring-primary' 
                        : 'hover:bg-muted/50'
                    }`}
                    onClick={() => setSelectedDelivery(option)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{option.logo}</span>
                          <div>
                            <p className="font-medium">{option.name}</p>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {option.estimatedTime} min
                            </p>
                          </div>
                        </div>
                        <p className="font-semibold">${option.fee.toFixed(2)}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Delivery Address */}
          <div className="space-y-2">
            <Label htmlFor="address">Delivery Address</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="address"
                placeholder="Enter your delivery address"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Special Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Special Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any special instructions for your order..."
              value={specialNotes}
              onChange={(e) => setSpecialNotes(e.target.value)}
              rows={3}
            />
          </div>

          <Separator />

          {/* Order Summary */}
          <div className="space-y-2">
            <h4 className="font-semibold">Order Summary</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Subtotal ({quantity} × ${dish.price.toFixed(2)})</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>${deliveryFee.toFixed(2)}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold text-base">
                <span>Total</span>
                <span className="text-primary">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="flex-1"
              disabled={isPlacingOrder}
            >
              Cancel
            </Button>
            <Button 
              onClick={handlePlaceOrder}
              className="flex-1"
              disabled={isPlacingOrder || !selectedDelivery}
            >
              {isPlacingOrder ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Placing Order...
                </>
              ) : (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Place Order
                </>
              )}
            </Button>
          </div>

          {/* Payment Notice */}
          <div className="text-center text-xs text-muted-foreground">
            <p>You'll be redirected to complete payment with {selectedDelivery?.name}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}