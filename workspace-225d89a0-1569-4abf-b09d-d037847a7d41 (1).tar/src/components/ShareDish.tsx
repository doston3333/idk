'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Share2, Copy, Heart, MapPin, Star } from 'lucide-react';
import { toast } from 'sonner';

interface Dish {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  restaurant: {
    name: string;
    address: string;
  };
}

interface ShareDishProps {
  dish: Dish;
  userId: string;
}

export default function ShareDish({ dish, userId }: ShareDishProps) {
  const [sharing, setSharing] = useState(false);

  const shareDish = async (platform: string) => {
    setSharing(true);
    try {
      const response = await fetch('/api/share', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          shareType: 'dish',
          itemId: dish.id,
          platform
        })
      });

      if (response.ok) {
        const data = await response.json();
        const { content } = data;

        if (platform === 'copy_link') {
          copyToClipboard(content.url);
        } else {
          // Open share dialog for social platforms
          const shareUrl = getShareUrl(platform, content);
          window.open(shareUrl, '_blank');
        }

        toast.success('Dish shared successfully!');
      }
    } catch (error) {
      console.error('Error sharing dish:', error);
      toast.error('Failed to share dish');
    } finally {
      setSharing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Link copied to clipboard!');
  };

  const getShareUrl = (platform: string, content: any) => {
    const { url, title, description } = content;
    const encodedUrl = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);
    const encodedDesc = encodeURIComponent(description);

    switch (platform) {
      case 'twitter':
        return `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`;
      case 'facebook':
        return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
      case 'whatsapp':
        return `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`;
      default:
        return url;
    }
  };

  return (
    <Card className="border-dashed">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Share this dish
          </h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => shareDish('copy_link')}
            disabled={sharing}
          >
            <Copy className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareDish('whatsapp')}
            disabled={sharing}
            className="flex items-center gap-2"
          >
            <Share2 className="h-4 w-4" />
            WhatsApp
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareDish('twitter')}
            disabled={sharing}
            className="flex items-center gap-2"
          >
            <Share2 className="h-4 w-4" />
            Twitter
          </Button>
        </div>

        <div className="bg-gray-50 p-3 rounded-lg">
          <h4 className="font-medium text-sm mb-1">Share preview:</h4>
          <div className="text-xs text-gray-600">
            <p className="font-medium">Check out this amazing dish: {dish.name}</p>
            <p>I found this delicious dish at {dish.restaurant.name} on FoodieMatch!</p>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            {dish.restaurant.name}
          </div>
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            Share & Earn
          </div>
        </div>
      </CardContent>
    </Card>
  );
}