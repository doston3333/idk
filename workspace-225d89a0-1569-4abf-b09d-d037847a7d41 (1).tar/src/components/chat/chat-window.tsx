'use client'

import React, { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Send, 
  Phone, 
  MapPin, 
  Clock, 
  Users, 
  MoreVertical,
  Paperclip,
  Smile
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { format } from 'date-fns'

interface Message {
  id: string
  content: string
  senderId: string
  senderName: string
  senderAvatar?: string
  messageType: 'text' | 'image' | 'file'
  isRead: boolean
  createdAt: string
  isOwn: boolean
}

interface ChatRoom {
  id: string
  type: 'user_restaurant' | 'user_user'
  restaurantId?: string
  restaurantName?: string
  otherUser: {
    id: string
    name: string
    avatar?: string
    isOnline?: boolean
  }
}

interface ChatWindowProps {
  chatRoom: ChatRoom
  currentUserId: string
  isOpen: boolean
  onClose: () => void
}

export function ChatWindow({ chatRoom, currentUserId, isOpen, onClose }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [otherUserTyping, setOtherUserTyping] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Fetch initial messages and setup WebSocket connection
  useEffect(() => {
    if (isOpen && chatRoom.id) {
      fetchMessages()
      setupWebSocketConnection()
    }

    return () => {
      // Cleanup WebSocket connection
      if (isConnected) {
        // Disconnect logic here
      }
    }
  }, [isOpen, chatRoom.id])

  const fetchMessages = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/chat/${chatRoom.id}/messages`)
      if (response.ok) {
        const data = await response.json()
        setMessages(data.messages.map((msg: any) => ({
          ...msg,
          isOwn: msg.senderId === currentUserId
        })))
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load messages',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  const setupWebSocketConnection = () => {
    // Mock WebSocket connection - in real app, use actual WebSocket
    setIsConnected(true)
    
    // Simulate receiving messages
    const mockInterval = setInterval(() => {
      if (Math.random() > 0.95) { // 5% chance of receiving a message
        const mockMessage: Message = {
          id: Date.now().toString(),
          content: getRandomMessage(),
          senderId: chatRoom.otherUser.id,
          senderName: chatRoom.otherUser.name,
          senderAvatar: chatRoom.otherUser.avatar,
          messageType: 'text',
          isRead: false,
          createdAt: new Date().toISOString(),
          isOwn: false
        }
        setMessages(prev => [...prev, mockMessage])
      }
    }, 10000)

    return () => clearInterval(mockInterval)
  }

  const getRandomMessage = () => {
    const messages = [
      "Hello! Welcome to our restaurant! 🍽️",
      "How can I help you today?",
      "Do you have any questions about our menu?",
      "We have some great specials today!",
      "What time would you like to visit?",
      "Our chef recommends the pasta of the day!",
      "Is this your first time dining with us?",
      "We look forward to serving you!"
    ]
    return messages[Math.floor(Math.random() * messages.length)]
  }

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return

    const messageContent = newMessage.trim()
    setNewMessage('')

    // Optimistically add message to UI
    const optimisticMessage: Message = {
      id: Date.now().toString(),
      content: messageContent,
      senderId: currentUserId,
      senderName: 'You',
      messageType: 'text',
      isRead: false,
      createdAt: new Date().toISOString(),
      isOwn: true
    }
    setMessages(prev => [...prev, optimisticMessage])

    try {
      const response = await fetch(`/api/chat/${chatRoom.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: messageContent,
          messageType: 'text'
        })
      })

      if (!response.ok) {
        throw new Error('Failed to send message')
      }

      // Mark message as sent (already in UI due to optimistic update)
    } catch (error) {
      toast({
        title: 'Message Failed',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive'
      })
      // Remove optimistic message on failure
      setMessages(prev => prev.filter(msg => msg.id !== optimisticMessage.id))
    }
  }

  const handleTyping = (value: string) => {
    setNewMessage(value)
    
    // Send typing indicator
    if (value.length > 0 && !isTyping) {
      setIsTyping(true)
      // Send typing indicator via WebSocket
      setTimeout(() => setIsTyping(false), 1000)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)
    
    if (diffInHours < 24) {
      return format(date, 'h:mm a')
    } else {
      return format(date, 'MMM d, h:mm a')
    }
  }

  if (!isOpen) return null

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-[600px] shadow-xl z-50">
      {/* Chat Header */}
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar className="h-10 w-10">
                <AvatarImage src={chatRoom.otherUser.avatar} />
                <AvatarFallback>
                  {chatRoom.otherUser.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {chatRoom.otherUser.isOnline && (
                <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
              )}
            </div>
            <div>
              <CardTitle className="text-lg">
                {chatRoom.restaurantName || chatRoom.otherUser.name}
              </CardTitle>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                {chatRoom.otherUser.isOnline ? (
                  <Badge variant="secondary" className="text-xs">Online</Badge>
                ) : (
                  <span>Offline</span>
                )}
                {isConnected && (
                  <Badge variant="outline" className="text-xs">Connected</Badge>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreVertical className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </div>
      </CardHeader>

      <Separator />

      {/* Messages Area */}
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-[400px] p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                <p className="text-sm text-muted-foreground">Loading messages...</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] ${message.isOwn ? 'order-2' : 'order-1'}`}>
                    {!message.isOwn && (
                      <div className="flex items-center gap-2 mb-1">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={message.senderAvatar} />
                          <AvatarFallback className="text-xs">
                            {message.senderName.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground">
                          {message.senderName}
                        </span>
                      </div>
                    )}
                    <div
                      className={`rounded-lg px-3 py-2 ${
                        message.isOwn
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <div className={`text-xs text-muted-foreground mt-1 ${
                      message.isOwn ? 'text-right' : 'text-left'
                    }`}>
                      {formatMessageTime(message.createdAt)}
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Typing Indicator */}
              {otherUserTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg px-3 py-2">
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>
      </CardContent>

      <Separator />

      {/* Message Input */}
      <div className="p-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm">
            <Paperclip className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Smile className="h-4 w-4" />
          </Button>
          <Input
            ref={inputRef}
            value={newMessage}
            onChange={(e) => handleTyping(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  )
}

// Chat List Component for showing all conversations
interface ChatListProps {
  currentUserId: string
  onChatSelect: (chatRoom: ChatRoom) => void
}

export function ChatList({ currentUserId, onChatSelect }: ChatListProps) {
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchChatRooms()
  }, [])

  const fetchChatRooms = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/chat/user/${currentUserId}/rooms`)
      if (response.ok) {
        const data = await response.json()
        setChatRooms(data.chatRooms)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load conversations',
        variant: 'destructive'
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-80">
      <CardHeader>
        <CardTitle className="text-lg">Messages</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="space-y-1">
              {chatRooms.map((chatRoom) => (
                <div
                  key={chatRoom.id}
                  onClick={() => onChatSelect(chatRoom)}
                  className="flex items-center gap-3 p-3 hover:bg-muted/50 cursor-pointer transition-colors"
                >
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={chatRoom.otherUser.avatar} />
                      <AvatarFallback>
                        {chatRoom.otherUser.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    {chatRoom.otherUser.isOnline && (
                      <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">
                        {chatRoom.restaurantName || chatRoom.otherUser.name}
                      </p>
                      <span className="text-xs text-muted-foreground">2m</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      Last message preview...
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}