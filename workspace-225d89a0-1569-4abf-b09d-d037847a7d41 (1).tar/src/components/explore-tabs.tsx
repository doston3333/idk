'use client'

import { useState } from 'react'
import { 
  Compass, 
  DollarSign, 
  Leaf, 
  Heart, 
  MapPin, 
  Star,
  Utensils
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

interface ExploreTab {
  id: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  description: string
  isPremium?: boolean
}

const exploreTabs: ExploreTab[] = [
  {
    id: 'for-you',
    label: 'For You',
    icon: Compass,
    description: 'Personalized recommendations'
  },
  {
    id: 'budget-eats',
    label: 'Budget Eats',
    icon: DollarSign,
    description: 'Affordable delicious options'
  },
  {
    id: 'vegan-delights',
    label: 'Vegan Delights',
    icon: Leaf,
    description: 'Plant-based favorites'
  },
  {
    id: 'date-night',
    label: 'Date Night',
    icon: Heart,
    description: 'Perfect for special occasions'
  },
  {
    id: 'authentic-local',
    label: 'Authentic Local',
    icon: MapPin,
    description: 'Taste the local culture'
  },
  {
    id: 'premium-picks',
    label: 'Premium Picks',
    icon: Star,
    description: 'Upscale dining experiences',
    isPremium: true
  }
]

interface ExploreTabsProps {
  activeTab: string
  onTabChange: (tabId: string) => void
  subscriptionTier: string
}

export default function ExploreTabs({ activeTab, onTabChange, subscriptionTier }: ExploreTabsProps) {
  const [showPremiumTooltip, setShowPremiumTooltip] = useState<string | null>(null)

  const handleTabClick = (tabId: string) => {
    const tab = exploreTabs.find(t => t.id === tabId)
    
    if (tab?.isPremium && subscriptionTier === 'free') {
      setShowPremiumTooltip(tabId)
      setTimeout(() => setShowPremiumTooltip(null), 2000)
      return
    }
    
    onTabChange(tabId)
  }

  return (
    <div className="relative">
      {/* Mobile Scroll */}
      <div className="lg:hidden overflow-x-auto pb-2">
        <div className="flex gap-2 min-w-max px-4">
          {exploreTabs.map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            const isLocked = tab.isPremium && subscriptionTier === 'free'
            
            return (
              <div key={tab.id} className="relative">
                <Button
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleTabClick(tab.id)}
                  disabled={isLocked}
                  className={cn(
                    "flex items-center gap-2 whitespace-nowrap",
                    isActive && "bg-primary text-primary-foreground",
                    isLocked && "opacity-50 cursor-not-allowed"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                  {tab.isPremium && (
                    <Star className="h-3 w-3 text-yellow-500 fill-current" />
                  )}
                </Button>
                
                {/* Premium Tooltip */}
                {showPremiumTooltip === tab.id && (
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap z-50">
                      Upgrade to Premium to access this tab
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1">
                        <div className="border-4 border-transparent border-t-gray-900"></div>
                      </div>
                    </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Desktop Grid */}
      <div className="hidden lg:grid lg:grid-cols-3 gap-4 mb-6">
        {exploreTabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id
          const isLocked = tab.isPremium && subscriptionTier === 'free'
          
          return (
            <div key={tab.id} className="relative">
              <button
                onClick={() => handleTabClick(tab.id)}
                disabled={isLocked}
                className={cn(
                  "w-full p-4 rounded-lg border-2 transition-all duration-200 text-left",
                  isActive 
                    ? "border-primary bg-primary/5 shadow-md" 
                    : "border-gray-200 hover:border-gray-300 hover:shadow-sm",
                  isLocked && "opacity-50 cursor-not-allowed"
                )}
              >
                <div className="flex items-start gap-3">
                  <div className={cn(
                    "p-2 rounded-lg",
                    isActive ? "bg-primary text-primary-foreground" : "bg-gray-100 text-gray-600"
                  )}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{tab.label}</h3>
                      {tab.isPremium && (
                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{tab.description}</p>
                  </div>
                </div>
              </button>
              
              {/* Premium Tooltip */}
              {showPremiumTooltip === tab.id && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap z-50">
                  Upgrade to Premium to access this tab
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1">
                    <div className="border-4 border-transparent border-t-gray-900"></div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Active Tab Description (Mobile) */}
      <div className="lg:hidden px-4 pb-4">
        {exploreTabs.find(tab => tab.id === activeTab) && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            {exploreTabs.find(tab => tab.id === activeTab)?.icon && 
              React.createElement(exploreTabs.find(tab => tab.id === activeTab)!.icon, { className: "h-4 w-4" })
            }
            <span>{exploreTabs.find(tab => tab.id === activeTab)?.description}</span>
          </div>
        )}
      </div>
    </div>
  )
}