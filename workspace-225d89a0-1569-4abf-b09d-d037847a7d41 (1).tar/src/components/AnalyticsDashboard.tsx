'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  TrendingUp, 
  Users, 
  Share2, 
  MousePointer, 
  Target,
  Calendar,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react';

interface AnalyticsData {
  timeframe: string;
  summary: {
    totalEvents: number;
    totalShares: number;
    totalClicks: number;
    totalConversions: number;
    clickThroughRate: number;
    conversionRate: number;
  };
  breakdowns: {
    eventTypes: Record<string, number>;
    platforms: Record<string, number>;
  };
  dailyActivity: Array<{ date: string; events: number }>;
  referralPerformance: {
    code: string;
    totalCoupons: number;
    usedCoupons: number;
    conversionRate: number;
  } | null;
  recentEvents: Array<{
    id: string;
    eventType: string;
    eventName: string;
    createdAt: string;
  }>;
  recentShares: Array<{
    id: string;
    shareType: string;
    platform: string;
    clicks: number;
    dish?: { name: string };
    restaurant?: { name: string };
  }>;
}

export default function AnalyticsDashboard({ userId }: { userId: string }) {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('30');

  useEffect(() => {
    fetchAnalytics();
  }, [userId, timeframe]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/analytics?userId=${userId}&timeframe=${timeframe}`);
      if (response.ok) {
        const data = await response.json();
        setAnalyticsData(data);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Analytics Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!analyticsData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Analytics Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <BarChart3 className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p>No analytics data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { summary, breakdowns, dailyActivity, referralPerformance, recentEvents, recentShares } = analyticsData;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Analytics Dashboard
            </CardTitle>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 days</SelectItem>
                <SelectItem value="30">30 days</SelectItem>
                <SelectItem value="90">90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <CardDescription>
            Track your referral performance and sharing activity
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="referrals">Referrals</TabsTrigger>
              <TabsTrigger value="shares">Shares</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-blue-600">
                      <Share2 className="h-4 w-4" />
                      <span className="text-sm font-medium">Total Shares</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.totalShares}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-green-600">
                      <MousePointer className="h-4 w-4" />
                      <span className="text-sm font-medium">Clicks</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.totalClicks}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-purple-600">
                      <Target className="h-4 w-4" />
                      <span className="text-sm font-medium">Conversions</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.totalConversions}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-orange-600">
                      <TrendingUp className="h-4 w-4" />
                      <span className="text-sm font-medium">CTR</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.clickThroughRate.toFixed(1)}%</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-pink-600">
                      <Activity className="h-4 w-4" />
                      <span className="text-sm font-medium">Conv. Rate</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.conversionRate.toFixed(1)}%</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-indigo-600">
                      <BarChart3 className="h-4 w-4" />
                      <span className="text-sm font-medium">Events</span>
                    </div>
                    <p className="text-2xl font-bold">{summary.totalEvents}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Event Types</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(breakdowns.eventTypes).map(([type, count]) => (
                        <div key={type} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{type.replace('_', ' ')}</span>
                          <Badge variant="secondary">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Share Platforms</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(breakdowns.platforms).map(([platform, count]) => (
                        <div key={platform} className="flex items-center justify-between">
                          <span className="text-sm capitalize">{platform}</span>
                          <Badge variant="secondary">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="referrals" className="space-y-4">
              {referralPerformance ? (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5" />
                        Referral Performance
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <p className="text-sm text-gray-600">Referral Code</p>
                          <p className="font-mono font-bold">{referralPerformance.code}</p>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm text-gray-600">Total Coupons</p>
                          <p className="text-2xl font-bold">{referralPerformance.totalCoupons}</p>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm text-gray-600">Used Coupons</p>
                          <p className="text-2xl font-bold text-green-600">{referralPerformance.usedCoupons}</p>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm text-gray-600">Conversion Rate</p>
                          <p className="text-2xl font-bold text-blue-600">
                            {referralPerformance.conversionRate.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-8">
                    <Users className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p>No referral performance data available</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="shares" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Shares</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentShares.map((share) => (
                      <div key={share.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium capitalize">{share.shareType}</p>
                          <p className="text-sm text-gray-600">
                            {share.dish?.name || share.restaurant?.name || 'General'}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline" className="capitalize">
                            {share.platform}
                          </Badge>
                          <p className="text-sm text-gray-600 mt-1">
                            {share.clicks} clicks
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Daily Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {dailyActivity.map((day) => (
                      <div key={day.date} className="flex items-center justify-between">
                        <span className="text-sm">{day.date}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${Math.min((day.events / 10) * 100, 100)}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium">{day.events}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Events</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {recentEvents.map((event) => (
                      <div key={event.id} className="flex items-center justify-between p-2 text-sm">
                        <span className="capitalize">{event.eventType.replace('_', ' ')}</span>
                        <span className="text-gray-600">
                          {new Date(event.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}