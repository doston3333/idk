'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, Share2, Gift, Users, TrendingUp, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ReferralData {
  referralCode: string;
  discountAmount: number;
  discountType: string;
  currentUses: number;
  maxUses: number;
  expiresAt: string;
  stats: {
    totalGenerated: number;
    totalUsed: number;
    conversionRate: number;
  };
}

export default function ReferralProgram({ userId }: { userId: string }) {
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [loading, setLoading] = useState(true);
  const [referralInput, setReferralInput] = useState('');
  const [applyingReferral, setApplyingReferral] = useState(false);

  useEffect(() => {
    fetchReferralData();
  }, [userId]);

  const fetchReferralData = async () => {
    try {
      const response = await fetch(`/api/referrals?userId=${userId}`);
      if (response.ok) {
        const data = await response.json();
        setReferralData(data);
      } else {
        // Create referral code if none exists
        createReferralCode();
      }
    } catch (error) {
      console.error('Error fetching referral data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createReferralCode = async () => {
    try {
      const response = await fetch('/api/referrals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });

      if (response.ok) {
        const data = await response.json();
        fetchReferralData(); // Refresh data
        toast.success('Referral code created successfully!');
      }
    } catch (error) {
      console.error('Error creating referral code:', error);
      toast.error('Failed to create referral code');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const shareReferral = async (platform: string) => {
    if (!referralData) return;

    try {
      const response = await fetch('/api/share', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          shareType: 'referral',
          platform
        })
      });

      if (response.ok) {
        const data = await response.json();
        const { content } = data;

        if (platform === 'copy_link') {
          copyToClipboard(content.url);
        } else {
          // Open share dialog for social platforms
          const shareUrl = getShareUrl(platform, content);
          window.open(shareUrl, '_blank');
        }

        toast.success('Referral shared successfully!');
      }
    } catch (error) {
      console.error('Error sharing referral:', error);
      toast.error('Failed to share referral');
    }
  };

  const getShareUrl = (platform: string, content: any) => {
    const { url, title, description } = content;
    const encodedUrl = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);
    const encodedDesc = encodeURIComponent(description);

    switch (platform) {
      case 'twitter':
        return `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`;
      case 'facebook':
        return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
      case 'whatsapp':
        return `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`;
      default:
        return url;
    }
  };

  const applyReferralCode = async () => {
    if (!referralInput.trim()) {
      toast.error('Please enter a referral code');
      return;
    }

    setApplyingReferral(true);
    try {
      const response = await fetch('/api/referrals/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          referralCode: referralInput.trim(),
          userId
        })
      });

      if (response.ok) {
        const data = await response.json();
        toast.success(`Coupon created! ${data.coupon.discountAmount} off your first order`);
        setReferralInput('');
      } else {
        const error = await response.json();
        toast.error(error.error || 'Failed to apply referral code');
      }
    } catch (error) {
      console.error('Error applying referral code:', error);
      toast.error('Failed to apply referral code');
    } finally {
      setApplyingReferral(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="h-5 w-5" />
            Referral Program
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="h-5 w-5" />
          Referral Program
        </CardTitle>
        <CardDescription>
          Share FoodieMatch with friends and earn rewards!
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="share" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="share">Share & Earn</TabsTrigger>
            <TabsTrigger value="apply">Apply Code</TabsTrigger>
          </TabsList>

          <TabsContent value="share" className="space-y-4">
            {referralData ? (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Your Referral Code</span>
                    <Badge variant="secondary">
                      ${referralData.discountAmount} OFF
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      value={referralData.referralCode}
                      readOnly
                      className="font-mono text-lg"
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(referralData.referralCode)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 text-blue-700">
                      <Users className="h-4 w-4" />
                      <span className="text-sm font-medium">Friends Invited</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-900">
                      {referralData.stats.totalGenerated}
                    </p>
                  </div>
                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm font-medium">Successful</span>
                    </div>
                    <p className="text-2xl font-bold text-green-900">
                      {referralData.stats.totalUsed}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Share your referral link</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareReferral('copy_link')}
                      className="flex items-center gap-2"
                    >
                      <Copy className="h-4 w-4" />
                      Copy Link
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareReferral('whatsapp')}
                      className="flex items-center gap-2"
                    >
                      <Share2 className="h-4 w-4" />
                      WhatsApp
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareReferral('twitter')}
                      className="flex items-center gap-2"
                    >
                      <Share2 className="h-4 w-4" />
                      Twitter
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareReferral('facebook')}
                      className="flex items-center gap-2"
                    >
                      <Share2 className="h-4 w-4" />
                      Facebook
                    </Button>
                  </div>
                </div>

                <div className="text-xs text-gray-500">
                  <p>• Friends get ${referralData.discountAmount} off their first order</p>
                  <p>• Code expires on {new Date(referralData.expiresAt).toLocaleDateString()}</p>
                  <p>• Maximum {referralData.maxUses} uses</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Gift className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium mb-2">Start Referring Friends</h3>
                <p className="text-gray-600 mb-4">
                  Get your unique referral code and start earning rewards
                </p>
                <Button onClick={createReferralCode}>
                  Create Referral Code
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="apply" className="space-y-4">
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Have a referral code?</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Enter a friend's referral code to get a discount on your first order
                </p>
              </div>
              
              <div className="flex gap-2">
                <Input
                  placeholder="Enter referral code"
                  value={referralInput}
                  onChange={(e) => setReferralInput(e.target.value.toUpperCase())}
                  className="font-mono"
                />
                <Button 
                  onClick={applyReferralCode}
                  disabled={applyingReferral}
                >
                  {applyingReferral ? 'Applying...' : 'Apply'}
                </Button>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">How it works:</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Enter your friend's referral code</li>
                  <li>• Get a discount coupon for your first order</li>
                  <li>• Coupon valid for 30 days</li>
                  <li>• Minimum order amount may apply</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}