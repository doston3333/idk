'use client'

import React, { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Shield, RefreshCw, Code } from 'lucide-react'
import { toast } from 'sonner'

const verificationSchema = z.object({
  code: z.string().length(6, 'Verification code must be 6 digits'),
})

type VerificationFormData = z.infer<typeof verificationSchema>

interface OTPVerificationProps {
  identifier: string
  type: 'email' | 'phone'
  onVerified: () => void
  onBack: () => void
}

export function OTPVerification({ identifier, type, onVerified, onBack }: OTPVerificationProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [isResending, setIsResending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [timeLeft, setTimeLeft] = useState(600) // 10 minutes in seconds
  const [developmentOTP, setDevelopmentOTP] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<VerificationFormData>({
    resolver: zodResolver(verificationSchema),
  })

  const watchedCode = watch('code')

  // Generate development OTP on mount
  useEffect(() => {
    const isDevelopment = process.env.NODE_ENV === 'development'
    if (isDevelopment) {
      // Generate a predictable OTP for development (based on identifier)
      const predictableOTP = identifier.substring(0, 6).padEnd(6, '0').replace(/[^0-9]/g, '0')
      const fallbackOTP = '123456' // Fallback if the above doesn't work
      setDevelopmentOTP(predictableOTP.length === 6 ? predictableOTP : fallbackOTP)
    }
  }, [identifier])

  // Timer for resend button
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [timeLeft])

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
  }

  const onSubmit = async (data: VerificationFormData) => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          identifier,
          code: data.code,
          type,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Verification failed')
      }

      toast.success(`${type === 'email' ? 'Email' : 'Phone'} verified successfully!`)
      onVerified()
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  const handleResend = async () => {
    if (timeLeft > 0) return

    setIsResending(true)
    setError(null)

    try {
      const isDevelopment = process.env.NODE_ENV === 'development'
      
      if (isDevelopment) {
        // In development, just reset the timer and show a new OTP
        const newOTP = Math.floor(100000 + Math.random() * 900000).toString()
        setDevelopmentOTP(newOTP)
        setTimeLeft(600)
        toast.success(`New verification code generated: ${newOTP}`)
      } else {
        // In production, call the resend endpoint
        const response = await fetch('/api/auth/resend', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            identifier,
            type,
          }),
        })

        if (!response.ok) {
          throw new Error('Failed to resend code')
        }

        setTimeLeft(600)
        toast.success('Verification code resent!')
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to resend code'
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setIsResending(false)
    }
  }

  const handleOTPChange = (value: string) => {
    setValue('code', value)
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
          <Shield className="h-6 w-6" />
          Verify Your {type === 'email' ? 'Email' : 'Phone'}
        </CardTitle>
        <CardDescription>
          We've sent a 6-digit verification code to {identifier}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Development Mode Alert */}
          {developmentOTP && (
            <Alert className="border-blue-200 bg-blue-50">
              <Code className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                <div className="space-y-2">
                  <p className="font-semibold">🔧 Development Mode</p>
                  <p>Use this verification code: <span className="font-mono bg-blue-100 px-2 py-1 rounded text-lg">{developmentOTP}</span></p>
                  <p className="text-xs">In production, this would be sent via email/SMS</p>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="code" className="text-center block">
              Enter Verification Code
            </Label>
            <div className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={watchedCode}
                onChange={handleOTPChange}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
            {errors.code && (
              <p className="text-sm text-destructive text-center">{errors.code.message}</p>
            )}
            
            {/* Development mode auto-fill button */}
            {developmentOTP && (
              <div className="text-center">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setValue('code', developmentOTP)
                    handleOTPChange(developmentOTP)
                  }}
                  className="text-xs"
                >
                  Auto-fill Code (Dev Mode)
                </Button>
              </div>
            )}
          </div>

          <input type="hidden" {...register('code')} />

          <Button type="submit" className="w-full" disabled={isLoading || watchedCode?.length !== 6}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              'Verify'
            )}
          </Button>

          <div className="text-center space-y-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleResend}
              disabled={timeLeft > 0 || isResending}
              className="w-full"
            >
              {isResending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Resending...
                </>
              ) : timeLeft > 0 ? (
                `Resend code in ${formatTime(timeLeft)}`
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Resend Code
                </>
              )}
            </Button>

            <Button
              type="button"
              variant="ghost"
              onClick={onBack}
              className="text-sm"
            >
              Back to Sign Up
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}