'use client'

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Camera, Upload, User, CheckCircle, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

interface ProfilePhotoProps {
  userId: string
  onNext: () => void
  onBack: () => void
  onSkip: () => void
}

export function ProfilePhoto({ userId, onNext, onBack, onSkip }: ProfilePhotoProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file')
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image size must be less than 5MB')
      return
    }

    setSelectedFile(file)
    setError(null)
    setUploadStatus('idle')

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setPreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleUpload = async () => {
    if (!selectedFile) return

    setIsUploading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append('file', selectedFile)
      formData.append('userId', userId)

      const response = await fetch('/api/upload/avatar', {
        method: 'POST',
        body: formData,
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Upload failed')
      }

      setUploadStatus('success')
      toast.success('Profile photo uploaded successfully!')
      
      // Auto-advance after successful upload
      setTimeout(() => {
        onNext()
      }, 1500)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Upload failed'
      setError(errorMessage)
      setUploadStatus('error')
      toast.error(errorMessage)
    } finally {
      setIsUploading(false)
    }
  }

  const handleRetake = () => {
    setSelectedFile(null)
    setPreview(null)
    setUploadStatus('idle')
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const openFileDialog = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Profile Photo</CardTitle>
          <CardDescription>
            Add a photo to personalize your profile (optional)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {uploadStatus === 'success' && (
            <Alert className="border-green-200 bg-green-50 text-green-800">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>Photo uploaded successfully!</AlertDescription>
            </Alert>
          )}

          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              {preview ? (
                <div className="relative">
                  <img
                    src={preview}
                    alt="Profile preview"
                    className="w-32 h-32 rounded-full object-cover border-4 border-primary"
                  />
                  {uploadStatus === 'success' && (
                    <div className="absolute -bottom-2 -right-2 bg-green-500 rounded-full p-1">
                      <CheckCircle className="h-6 w-6 text-white" />
                    </div>
                  )}
                </div>
              ) : (
                <div className="w-32 h-32 rounded-full bg-muted border-2 border-dashed border-muted-foreground flex items-center justify-center">
                  <User className="h-12 w-12 text-muted-foreground" />
                </div>
              )}
            </div>

            {!preview ? (
              <div className="text-center space-y-4">
                <p className="text-sm text-muted-foreground">
                  Upload a clear photo of yourself. This helps others connect with you better.
                </p>
                <div className="space-y-2">
                  <Button onClick={openFileDialog} className="w-full">
                    <Camera className="mr-2 h-4 w-4" />
                    Take Photo
                  </Button>
                  <Button variant="outline" onClick={openFileDialog} className="w-full">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload from Gallery
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <p className="text-sm text-muted-foreground">
                  Great choice! Your photo will be reviewed for appropriateness.
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleRetake} disabled={isUploading}>
                    Retake
                  </Button>
                  <Button 
                    onClick={handleUpload} 
                    disabled={isUploading || uploadStatus === 'success'}
                  >
                    {isUploading ? 'Uploading...' : 'Use This Photo'}
                  </Button>
                </div>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            capture="environment"
          />

          <div className="text-xs text-muted-foreground space-y-1">
            <p>• Photos are reviewed for appropriateness</p>
            <p>• Maximum file size: 5MB</p>
            <p>• Supported formats: JPG, PNG, GIF</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <div className="space-x-2">
          <Button variant="ghost" onClick={onSkip}>
            Skip for Now
          </Button>
          {uploadStatus === 'success' && (
            <Button onClick={onNext}>
              Continue
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}