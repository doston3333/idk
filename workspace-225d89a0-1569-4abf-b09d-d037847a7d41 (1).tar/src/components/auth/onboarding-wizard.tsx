'use client'

import { useState } from 'react'
import { SignupForm } from './signup-form'
import { OTPVerification } from './otp-verification'
import { DietaryPreferences, DietaryPreferencesData } from './dietary-preferences'
import { PriceDistancePreferences, PriceDistanceData } from './price-distance-preferences'
import { ProfilePhoto } from './profile-photo'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { CheckCircle } from 'lucide-react'
import { useAuth } from '@/contexts/auth-context'

interface OnboardingWizardProps {
  onComplete: (userDataWithRole?: any) => void
  initialUserData?: any
}

type Step = 'signup' | 'preferences' | 'price-distance' | 'photo' | 'complete'

export function OnboardingWizard({ onComplete, initialUserData }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState<Step>(initialUserData ? 'preferences' : 'signup')
  const [userData, setUserData] = useState({
    userId: initialUserData?.id || '',
    email: initialUserData?.email || '',
    phone: initialUserData?.phone || '',
    role: initialUserData?.role || 'user',
    ...initialUserData
  })
  const [preferences, setPreferences] = useState<DietaryPreferencesData>({
    dietaryRestrictions: [],
    allergies: [],
    favoriteCuisines: [],
  })
  const [priceDistance, setPriceDistance] = useState<PriceDistanceData>({
    priceRange: 'medium',
    searchRadius: 10,
  })
  const { updateUser } = useAuth()

  const steps = [
    { id: 'signup', label: 'Account', completed: false },
    { id: 'preferences', label: 'Preferences', completed: false },
    { id: 'price-distance', label: 'Location', completed: false },
    { id: 'photo', label: 'Photo', completed: false },
  ]

  const getCurrentStepIndex = () => {
    return steps.findIndex(step => step.id === currentStep)
  }

  const getProgress = () => {
    const currentIndex = getCurrentStepIndex()
    return ((currentIndex + 1) / steps.length) * 100
  }

  const updateStepCompleted = (stepId: Step, completed: boolean) => {
    const stepIndex = steps.findIndex(step => step.id === stepId)
    if (stepIndex !== -1) {
      steps[stepIndex].completed = completed
    }
  }

  const handleSignupSuccess = (userId: string, email: string, phone?: string) => {
    setUserData({ userId, email, phone: phone || '' })
    updateStepCompleted('signup', true)
    setCurrentStep('preferences') // Skip verification, go directly to preferences
  }

  const handlePreferencesNext = (data: DietaryPreferencesData) => {
    setPreferences(data)
    updateStepCompleted('preferences', true)
    setCurrentStep('price-distance')
  }

  const handlePriceDistanceNext = (data: PriceDistanceData) => {
    setPriceDistance(data)
    updateStepCompleted('price-distance', true)
    setCurrentStep('photo')
  }

  const handlePhotoNext = () => {
    updateStepCompleted('photo', true)
    submitOnboarding()
  }

  const handlePhotoSkip = () => {
    updateStepCompleted('photo', true)
    submitOnboarding()
  }

  const submitOnboarding = async () => {
    try {
      const response = await fetch('/api/onboarding/preferences', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: userData.userId,
          ...preferences,
          ...priceDistance,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to save preferences')
      }

      // Fetch user data to get role information
      const userResponse = await fetch(`/api/auth/user?userId=${userData.userId}`)
      let userDataWithRole = userData
      if (userResponse.ok) {
        const userDataFromAPI = await userResponse.json()
        // Update user state with role information
        userDataWithRole = { ...userData, ...userDataFromAPI, onboardingCompleted: true }
        setUserData(userDataWithRole)
        
        // Update AuthContext with the latest user data
        updateUser({
          role: userDataFromAPI.role,
          onboardingCompleted: true
        })
        
        // Also update localStorage directly to ensure persistence
        localStorage.setItem('user', JSON.stringify(userDataWithRole))
      }

      setCurrentStep('complete')
      
      // Call onComplete with updated user data immediately
      setTimeout(() => {
        onComplete(userDataWithRole)
      }, 1000) // Reduced delay further
    } catch (error) {
      console.error('Onboarding submission error:', error)
      // Still proceed even if there's an error
      const fallbackUser = { ...userData, onboardingCompleted: true }
      setCurrentStep('complete')
      setTimeout(() => {
        onComplete(fallbackUser)
      }, 1000)
    }
  }

  const handleBack = () => {
    const currentIndex = getCurrentStepIndex()
    if (currentIndex > 0) {
      setCurrentStep(steps[currentIndex - 1].id as Step)
    }
  }

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'signup':
        return (
          <SignupForm
            onSuccess={handleSignupSuccess}
            onSwitchToPhone={() => {}} // TODO: Implement phone signup
          />
        )
      case 'preferences':
        return (
          <DietaryPreferences
            onNext={handlePreferencesNext}
            onBack={handleBack}
          />
        )
      case 'price-distance':
        return (
          <PriceDistancePreferences
            onNext={handlePriceDistanceNext}
            onBack={handleBack}
          />
        )
      case 'photo':
        return (
          <ProfilePhoto
            userId={userData.userId}
            onNext={handlePhotoNext}
            onBack={handleBack}
            onSkip={handlePhotoSkip}
          />
        )
      case 'complete':
        return (
          <Card className="w-full max-w-md mx-auto">
            <CardContent className="pt-6 text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Welcome to FoodieMatch! 🎉</h2>
                <p className="text-muted-foreground">
                  Your profile is all set up. Get ready to discover amazing dishes!
                </p>
              </div>
            </CardContent>
          </Card>
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Progress indicator */}
        {currentStep !== 'complete' && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold">Create Your Account</h1>
              <span className="text-sm text-muted-foreground">
                Step {getCurrentStepIndex() + 1} of {steps.length}
              </span>
            </div>
            <Progress value={getProgress()} className="h-2" />
            <div className="flex justify-between mt-2">
              {steps.map((step, index) => (
                <div
                  key={step.id}
                  className={`flex items-center space-x-2 text-xs ${
                    index <= getCurrentStepIndex() ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  {step.completed ? (
                    <CheckCircle className="h-3 w-3" />
                  ) : (
                    <div
                      className={`w-3 h-3 rounded-full border ${
                        index <= getCurrentStepIndex()
                          ? 'border-primary bg-primary'
                          : 'border-muted-foreground'
                      }`}
                    />
                  )}
                  <span className="hidden sm:inline">{step.label}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Current step content */}
        <div className="flex items-center justify-center">
          {renderCurrentStep()}
        </div>
      </div>
    </div>
  )
}