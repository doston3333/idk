'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { Leaf, AlertTriangle, ChefHat } from 'lucide-react'

interface DietaryPreferencesProps {
  onNext: (data: DietaryPreferencesData) => void
  onBack: () => void
}

export interface DietaryPreferencesData {
  dietaryRestrictions: string[]
  allergies: string[]
  favoriteCuisines: string[]
}

const DIETARY_RESTRICTIONS = [
  { id: 'vegan', label: 'Vegan', icon: '🌱' },
  { id: 'vegetarian', label: 'Vegetarian', icon: '🥗' },
  { id: 'gluten-free', label: 'Gluten-Free', icon: '🌾' },
  { id: 'halal', label: 'Halal', icon: '☪️' },
  { id: 'kosher', label: 'Kosher', icon: '✡️' },
  { id: 'dairy-free', label: 'Dairy-Free', icon: '🥛' },
  { id: 'keto', label: 'Keto', icon: '🥑' },
  { id: 'paleo', label: 'Paleo', icon: '🦴' },
]

const ALLERGIES = [
  { id: 'nuts', label: 'Nuts', icon: '🥜' },
  { id: 'peanuts', label: 'Peanuts', icon: '🥜' },
  { id: 'dairy', label: 'Dairy', icon: '🥛' },
  { id: 'eggs', label: 'Eggs', icon: '🥚' },
  { id: 'shellfish', label: 'Shellfish', icon: '🦐' },
  { id: 'fish', label: 'Fish', icon: '🐟' },
  { id: 'soy', label: 'Soy', icon: '🫘' },
  { id: 'wheat', label: 'Wheat', icon: '🌾' },
  { id: 'sesame', label: 'Sesame', icon: '🫘' },
]

const CUISINES = [
  { id: 'italian', label: 'Italian', icon: '🍝' },
  { id: 'chinese', label: 'Chinese', icon: '🥡' },
  { id: 'japanese', label: 'Japanese', icon: '🍱' },
  { id: 'mexican', label: 'Mexican', icon: '🌮' },
  { id: 'indian', label: 'Indian', icon: '🍛' },
  { id: 'thai', label: 'Thai', icon: '🍜' },
  { id: 'french', label: 'French', icon: '🥐' },
  { id: 'american', label: 'American', icon: '🍔' },
  { id: 'mediterranean', label: 'Mediterranean', icon: '🫒' },
  { id: 'korean', label: 'Korean', icon: '🥘' },
  { id: 'vietnamese', label: 'Vietnamese', icon: '🍲' },
  { id: 'uzbek', label: 'Uzbek', icon: '🍛' },
]

export function DietaryPreferences({ onNext, onBack }: DietaryPreferencesProps) {
  const [selectedRestrictions, setSelectedRestrictions] = useState<string[]>([])
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>([])
  const [selectedCuisines, setSelectedCuisines] = useState<string[]>([])

  const handleRestrictionToggle = (value: string) => {
    setSelectedRestrictions(prev =>
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    )
  }

  const handleAllergyToggle = (value: string) => {
    setSelectedAllergies(prev =>
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    )
  }

  const handleCuisineToggle = (value: string) => {
    setSelectedCuisines(prev =>
      prev.includes(value)
        ? prev.filter(item => item !== value)
        : [...prev, value]
    )
  }

  const handleSubmit = () => {
    const data: DietaryPreferencesData = {
      dietaryRestrictions: selectedRestrictions,
      allergies: selectedAllergies,
      favoriteCuisines: selectedCuisines,
    }
    onNext(data)
  }

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-green-600" />
            Dietary Preferences
          </CardTitle>
          <CardDescription>
            Select any dietary restrictions that apply to you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {DIETARY_RESTRICTIONS.map((restriction) => (
              <div
                key={restriction.id}
                className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => handleRestrictionToggle(restriction.id)}
              >
                <Checkbox
                  id={restriction.id}
                  checked={selectedRestrictions.includes(restriction.id)}
                  onChange={() => handleRestrictionToggle(restriction.id)}
                />
                <label
                  htmlFor={restriction.id}
                  className="flex items-center gap-2 cursor-pointer flex-1"
                >
                  <span className="text-lg">{restriction.icon}</span>
                  <span className="text-sm font-medium">{restriction.label}</span>
                </label>
              </div>
            ))}
          </div>
          {selectedRestrictions.length > 0 && (
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-2">Selected:</p>
              <div className="flex flex-wrap gap-2">
                {selectedRestrictions.map(restriction => {
                  const item = DIETARY_RESTRICTIONS.find(r => r.id === restriction)
                  return (
                    <Badge key={restriction} variant="secondary">
                      {item?.icon} {item?.label}
                    </Badge>
                  )
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-orange-600" />
            Allergies
          </CardTitle>
          <CardDescription>
            Select any food allergies. This helps us keep you safe.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {ALLERGIES.map((allergy) => (
              <div
                key={allergy.id}
                className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => handleAllergyToggle(allergy.id)}
              >
                <Checkbox
                  id={`allergy-${allergy.id}`}
                  checked={selectedAllergies.includes(allergy.id)}
                  onChange={() => handleAllergyToggle(allergy.id)}
                />
                <label
                  htmlFor={`allergy-${allergy.id}`}
                  className="flex items-center gap-2 cursor-pointer flex-1"
                >
                  <span className="text-lg">{allergy.icon}</span>
                  <span className="text-sm font-medium">{allergy.label}</span>
                </label>
              </div>
            ))}
          </div>
          {selectedAllergies.length > 0 && (
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-2">Selected:</p>
              <div className="flex flex-wrap gap-2">
                {selectedAllergies.map(allergy => {
                  const item = ALLERGIES.find(a => a.id === allergy)
                  return (
                    <Badge key={allergy} variant="destructive">
                      {item?.icon} {item?.label}
                    </Badge>
                  )
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChefHat className="h-6 w-6 text-blue-600" />
            Favorite Cuisines
          </CardTitle>
          <CardDescription>
            Select your favorite cuisines to get better recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {CUISINES.map((cuisine) => (
              <div
                key={cuisine.id}
                className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => handleCuisineToggle(cuisine.id)}
              >
                <Checkbox
                  id={`cuisine-${cuisine.id}`}
                  checked={selectedCuisines.includes(cuisine.id)}
                  onChange={() => handleCuisineToggle(cuisine.id)}
                />
                <label
                  htmlFor={`cuisine-${cuisine.id}`}
                  className="flex items-center gap-2 cursor-pointer flex-1"
                >
                  <span className="text-lg">{cuisine.icon}</span>
                  <span className="text-sm font-medium">{cuisine.label}</span>
                </label>
              </div>
            ))}
          </div>
          {selectedCuisines.length > 0 && (
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-2">Selected:</p>
              <div className="flex flex-wrap gap-2">
                {selectedCuisines.map(cuisine => {
                  const item = CUISINES.find(c => c.id === cuisine)
                  return (
                    <Badge key={cuisine} variant="default">
                      {item?.icon} {item?.label}
                    </Badge>
                  )
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button onClick={handleSubmit}>
          Next
        </Button>
      </div>
    </div>
  )
}