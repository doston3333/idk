'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { DollarSign, MapPin, ChefHat } from 'lucide-react'

interface PriceDistanceProps {
  onNext: (data: PriceDistanceData) => void
  onBack: () => void
}

export interface PriceDistanceData {
  priceRange: 'low' | 'medium' | 'high'
  searchRadius: number
}

const PRICE_RANGES = [
  {
    value: 'low',
    label: 'Budget Friendly',
    description: '$ - Under $15 per person',
    icon: '💰',
  },
  {
    value: 'medium',
    label: 'Mid-Range',
    description: '$$ - $15-40 per person',
    icon: '💵',
  },
  {
    value: 'high',
    label: 'Fine Dining',
    description: '$$$ - $40+ per person',
    icon: '💎',
  },
]

export function PriceDistancePreferences({ onNext, onBack }: PriceDistanceProps) {
  const [priceRange, setPriceRange] = useState<'low' | 'medium' | 'high'>('medium')
  const [searchRadius, setSearchRadius] = useState([10]) // Default 10km

  const handleSubmit = () => {
    const data: PriceDistanceData = {
      priceRange,
      searchRadius: searchRadius[0],
    }
    onNext(data)
  }

  const getRadiusLabel = (radius: number) => {
    if (radius <= 5) return 'Very Local'
    if (radius <= 10) return 'Neighborhood'
    if (radius <= 25) return 'City Wide'
    return 'Adventure Mode'
  }

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-6 w-6 text-green-600" />
            Price Range
          </CardTitle>
          <CardDescription>
            What's your preferred budget for dining out?
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup value={priceRange} onValueChange={(value) => setPriceRange(value as any)}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {PRICE_RANGES.map((range) => (
                <div key={range.value} className="relative">
                  <RadioGroupItem
                    value={range.value}
                    id={range.value}
                    className="sr-only"
                  />
                  <Label
                    htmlFor={range.value}
                    className={`
                      flex flex-col items-center justify-center p-4 border-2 rounded-lg cursor-pointer transition-all
                      ${priceRange === range.value 
                        ? 'border-primary bg-primary/5' 
                        : 'border-muted hover:border-primary/50'
                      }
                    `}
                  >
                    <span className="text-3xl mb-2">{range.icon}</span>
                    <span className="font-semibold text-center">{range.label}</span>
                    <span className="text-sm text-muted-foreground text-center mt-1">
                      {range.description}
                    </span>
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-6 w-6 text-blue-600" />
            Search Radius
          </CardTitle>
          <CardDescription>
            How far are you willing to travel for amazing food?
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label>Distance: {searchRadius[0]} km</Label>
              <span className="text-sm text-muted-foreground font-medium">
                {getRadiusLabel(searchRadius[0])}
              </span>
            </div>
            <Slider
              value={searchRadius}
              onValueChange={setSearchRadius}
              max={50}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1 km</span>
              <span>25 km</span>
              <span>50 km</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[1, 5, 10, 25].map((radius) => (
              <Button
                key={radius}
                variant={searchRadius[0] === radius ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSearchRadius([radius])}
              >
                {radius} km
              </Button>
            ))}
          </div>

          <div className="p-4 bg-muted/30 rounded-lg">
            <h4 className="font-medium mb-2">What this means:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• We'll show you restaurants within {searchRadius[0]} km of your location</li>
              <li>• You can change this anytime in your preferences</li>
              <li>• Smaller radius = more local, personalized recommendations</li>
              <li>• Larger radius = more variety and options</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button onClick={handleSubmit}>
          Next
        </Button>
      </div>
    </div>
  )
}