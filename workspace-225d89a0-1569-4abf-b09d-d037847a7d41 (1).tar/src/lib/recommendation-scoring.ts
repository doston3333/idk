// ============================================================================
// RECOMMENDATION SCORING CONFIGURATION
// ============================================================================
// 
// This file contains all the configuration and scoring logic for the
// recommendation algorithm. It's designed to be easily extensible and
// tunable without modifying the core algorithm logic.
// ============================================================================

export interface ScoringWeights {
  tasteMatch: number
  recency: number
  popularity: number
  diversity: number
  exploration: number
}

export interface AlgorithmConfig {
  maxRadiusKm: number
  defaultExplorationQuota: number
  recencyBoostDays: number
  minSampleSize: number
  diversityBoostFactor: number
  trendingThreshold: number
}

export interface ScoringFactors {
  tasteMatch: number
  recency: number
  popularity: number
  diversity: number
  exploration: number
}

export interface CandidateScore {
  candidateId: string
  finalScore: number
  scoreBreakdown: ScoringFactors
}

// Default scoring weights - these can be tuned based on user feedback
export const DEFAULT_SCORING_WEIGHTS: ScoringWeights = {
  tasteMatch: 0.35,      // 35% - How well it matches user preferences
  recency: 0.20,         // 20% - Newer items get boosted
  popularity: 0.25,      // 25% - Like/save ratio and engagement
  diversity: 0.15,       // 15% - Boost underrepresented cuisines
  exploration: 0.05      // 5% - Random exploration factor
}

// Algorithm configuration constants
export const DEFAULT_ALGORITHM_CONFIG: AlgorithmConfig = {
  maxRadiusKm: 50,           // Maximum search radius
  defaultExplorationQuota: 15, // 15% exploration by default
  recencyBoostDays: 7,       // Items added in last 7 days get boost
  minSampleSize: 10,         // Minimum candidates for diversity calculations
  diversityBoostFactor: 1.5, // Multiplier for underrepresented cuisines
  trendingThreshold: 10,     // Minimum likes to be considered trending
}

// ============================================================================
// SCORING FACTOR CALCULATORS
// ============================================================================

/**
 * Calculate taste match score based on user preferences
 * 
 * Factors considered:
 * - Favorite cuisines match (+25 points)
 * - Dietary restrictions compatibility (+5 points per match)
 * - Price range preference (+10 for exact, +5 for close)
 * - Historical swipe patterns (future enhancement)
 * 
 * @param candidate - The dish candidate
 * @param user - The user with preferences
 * @returns Taste match score (0-100)
 */
export function calculateTasteMatchScore(candidate: any, user: any): number {
  let score = 50 // Base score
  
  // Boost for favorite cuisines
  const userFavoriteCuisines = user.favoriteCuisines?.map((fc: any) => fc.type.toLowerCase()) || []
  if (userFavoriteCuisines.includes(candidate.cuisine.toLowerCase())) {
    score += 25
  }
  
  // Check dietary compatibility
  const candidateDietaryTags = candidate.dishDietaryTags?.map((tag: any) => tag.tag.toLowerCase()) || []
  const userDietaryRestrictions = user.dietaryRestrictions?.map((dr: any) => dr.type.toLowerCase()) || []
  
  // Positive boost for matching dietary preferences
  const matchingDietaryTags = candidateDietaryTags.filter(tag => 
    userDietaryRestrictions.includes(tag)
  )
  score += matchingDietaryTags.length * 5
  
  // Price range preference
  if (user.priceRange && candidate.priceRange === user.priceRange) {
    score += 10
  } else if (user.priceRange && 
    ((user.priceRange === 'low' && candidate.priceRange === 'medium') ||
     (user.priceRange === 'medium' && candidate.priceRange === 'high'))) {
    score += 5 // Close price range
  }
  
  return Math.min(100, score)
}

/**
 * Calculate recency score to boost new items
 * 
 * Recency decay function:
 * - Days 0-7: Full boost (100 points)
 * - Days 8-30: Linear decay from 100 to 0
 * - Days 31+: No boost (0 points)
 * 
 * @param candidate - The dish candidate
 * @returns Recency score (0-100)
 */
export function calculateRecencyScore(candidate: any, config: AlgorithmConfig = DEFAULT_ALGORITHM_CONFIG): number {
  const now = new Date()
  const createdAt = new Date(candidate.createdAt)
  const daysDiff = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24)
  
  if (daysDiff <= config.recencyBoostDays) {
    return 100 // Full recency boost for very new items
  } else if (daysDiff <= 30) {
    // Linear decay from 100 to 0 over 30 days
    const decayRate = 100 / (30 - config.recencyBoostDays)
    return Math.max(0, 100 - (daysDiff - config.recencyBoostDays) * decayRate)
  }
  
  return 0 // No recency boost for older items
}

/**
 * Calculate popularity score based on engagement metrics
 * 
 * Popularity factors:
 * - Average rating (0-50 points, rating 1-5 maps to 10-50)
 * - Engagement bonus (25 points for trending, 10 for some engagement)
 * - Quality bonus (25 points for 4.5+ rating with 10+ reviews)
 * 
 * @param candidate - The dish candidate
 * @param config - Algorithm configuration
 * @returns Popularity score (0-100)
 */
export function calculatePopularityScore(candidate: any, config: AlgorithmConfig = DEFAULT_ALGORITHM_CONFIG): number {
  const totalSwipes = candidate._count?.swipeActions || 0
  const avgRating = candidate.reviews?.length > 0
    ? candidate.reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / candidate.reviews.length
    : 0
  
  // Base score from rating (0-50 points)
  let score = avgRating * 10 // Rating 1-5 maps to 10-50 points
  
  // Bonus for high engagement (more reliable data)
  if (totalSwipes >= config.trendingThreshold) {
    score += 25 // Trending bonus
  } else if (totalSwipes >= 5) {
    score += 10 // Some engagement bonus
  }
  
  // Bonus for high rating with sufficient data
  if (avgRating >= 4.5 && totalSwipes >= 10) {
    score += 25 // Exceptional quality bonus
  }
  
  return Math.min(100, score)
}

/**
 * Calculate diversity score to boost underrepresented cuisines
 * 
 * Diversity strategy:
 * - Calculate cuisine distribution in current candidate pool
 * - Boost underrepresented cuisines (< 15% of pool)
 * - Penalize overrepresented cuisines (> 50% of pool)
 * - Prevent filter bubbles and ensure variety
 * 
 * @param candidate - The dish candidate
 * @param allCandidates - All candidates in the pool
 * @param config - Algorithm configuration
 * @returns Diversity score (0-100)
 */
export function calculateDiversityScore(
  candidate: any, 
  allCandidates: any[], 
  config: AlgorithmConfig = DEFAULT_ALGORITHM_CONFIG
): number {
  if (allCandidates.length < config.minSampleSize) {
    return 50 // Neutral score for small sample sizes
  }
  
  // Calculate cuisine distribution
  const cuisineCounts: Record<string, number> = {}
  allCandidates.forEach(c => {
    cuisineCounts[c.cuisine] = (cuisineCounts[c.cuisine] || 0) + 1
  })
  
  const totalCandidates = allCandidates.length
  const candidateCuisineCount = cuisineCounts[candidate.cuisine] || 0
  const cuisinePercentage = (candidateCuisineCount / totalCandidates) * 100
  
  // Boost underrepresented cuisines (less than 15% of pool)
  if (cuisinePercentage < 15) {
    return 100 // Maximum diversity boost
  } else if (cuisinePercentage < 25) {
    return 75 // Good diversity boost
  } else if (cuisinePercentage > 50) {
    return 25 // Penalty for overrepresented cuisines
  }
  
  return 50 // Neutral score for balanced representation
}

/**
 * Calculate exploration score for serendipity
 * 
 * Exploration strategy:
 * - Small random factor to introduce variety
 * - Helps users discover new things
 * - Prevents over-optimization
 * 
 * @returns Exploration score (0-100)
 */
export function calculateExplorationScore(): number {
  return Math.random() * 20 // 0-20 random score
}

/**
 * Compute comprehensive score for a candidate based on multiple factors
 * 
 * Final score calculation:
 * score = (taste_match * weight_taste) + (recency * weight_recency) + 
 *         (popularity * weight_popularity) + (diversity * weight_diversity) + 
 *         (exploration * weight_exploration)
 * 
 * @param candidate - The dish candidate
 * @param user - The user with preferences
 * @param allCandidates - All candidates in the pool
 * @param weights - Scoring weights
 * @param config - Algorithm configuration
 * @returns Comprehensive candidate score
 */
export async function computeCandidateScore(
  candidate: any,
  user: any,
  allCandidates: any[],
  weights: ScoringWeights = DEFAULT_SCORING_WEIGHTS,
  config: AlgorithmConfig = DEFAULT_ALGORITHM_CONFIG
): Promise<CandidateScore> {
  
  // Calculate individual factor scores
  const tasteMatch = calculateTasteMatchScore(candidate, user)
  const recency = calculateRecencyScore(candidate, config)
  const popularity = calculatePopularityScore(candidate, config)
  const diversity = calculateDiversityScore(candidate, allCandidates, config)
  const exploration = calculateExplorationScore()

  // Calculate final weighted score
  const finalScore = 
    (tasteMatch * weights.tasteMatch) +
    (recency * weights.recency) +
    (popularity * weights.popularity) +
    (diversity * weights.diversity) +
    (exploration * weights.exploration)

  return {
    candidateId: candidate.id,
    finalScore: Math.min(100, Math.max(0, finalScore)), // Clamp to 0-100
    scoreBreakdown: {
      tasteMatch,
      recency,
      popularity,
      diversity,
      exploration
    }
  }
}

/**
 * Inject exploration items to avoid filter bubbles
 * 
 * Exploration strategy:
 * - Select random items from lower-scoring candidates
 * - Include trending items that user might not see otherwise
 * - Ensure some serendipity in recommendations
 * 
 * @param scoredCandidates - Candidates with scores
 * @param allCandidates - All candidate data
 * @param explorationCount - Number of exploration items to inject
 * @param config - Algorithm configuration
 * @returns Candidates with exploration items injected
 */
export function injectExplorationItems(
  scoredCandidates: CandidateScore[],
  allCandidates: any[],
  explorationCount: number,
  config: AlgorithmConfig = DEFAULT_ALGORITHM_CONFIG
): CandidateScore[] {
  if (explorationCount <= 0 || scoredCandidates.length <= explorationCount) {
    return scoredCandidates
  }
  
  // Sort by score (ascending) to find lower-scoring candidates
  const sortedByScore = [...scoredCandidates].sort((a, b) => a.finalScore - b.finalScore)
  
  // Select exploration candidates from bottom 30% of scores
  const explorationPoolSize = Math.floor(sortedByScore.length * 0.3)
  const explorationPool = sortedByScore.slice(0, Math.max(1, explorationPoolSize))
  
  // Randomly select from exploration pool
  const explorationCandidates: CandidateScore[] = []
  const availableForExploration = Math.min(explorationCount, explorationPool.length)
  
  for (let i = 0; i < availableForExploration; i++) {
    const randomIndex = Math.floor(Math.random() * explorationPool.length)
    const selected = explorationPool.splice(randomIndex, 1)[0]
    
    // Boost exploration candidate score to ensure it appears in results
    explorationCandidates.push({
      ...selected,
      finalScore: Math.min(100, selected.finalScore + 30), // Exploration boost
      scoreBreakdown: {
        ...selected.scoreBreakdown,
        exploration: 100 // Mark as exploration item
      }
    })
  }
  
  // Combine main candidates with exploration candidates
  const mainCandidates = scoredCandidates.filter(sc => 
    !explorationCandidates.find(ec => ec.candidateId === sc.candidateId)
  )
  
  return [...mainCandidates, ...explorationCandidates]
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Calculate distance between two coordinates in kilometers
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371 // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

/**
 * Calculate score distribution for metadata
 */
export function calculateScoreDistribution(recommendations: CandidateScore[]) {
  const distribution = { high: 0, medium: 0, low: 0 }
  
  recommendations.forEach(rec => {
    if (rec.finalScore >= 70) distribution.high++
    else if (rec.finalScore >= 40) distribution.medium++
    else distribution.low++
  })
  
  return distribution
}

/**
 * Validate and normalize scoring weights
 */
export function validateScoringWeights(weights: Partial<ScoringWeights>): ScoringWeights {
  const total = Object.values(weights).reduce((sum, weight) => sum + (weight || 0), 0)
  
  if (Math.abs(total - 1.0) > 0.01) {
    console.warn('Scoring weights do not sum to 1.0, normalizing...')
    const normalizedWeights = { ...DEFAULT_SCORING_WEIGHTS, ...weights }
    const currentTotal = Object.values(normalizedWeights).reduce((sum, weight) => sum + weight, 0)
    
    // Normalize to sum to 1.0
    Object.keys(normalizedWeights).forEach(key => {
      (normalizedWeights as any)[key] = (normalizedWeights as any)[key] / currentTotal
    })
    
    return normalizedWeights
  }
  
  return { ...DEFAULT_SCORING_WEIGHTS, ...weights } as ScoringWeights
}