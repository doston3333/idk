import { getServerSession } from 'next-auth'
import { db } from '@/lib/db'

export async function getCurrentUser() {
  try {
    // For now, we'll use a simple session approach
    // In a real app, you'd use NextAuth or another auth solution
    const session = await getServerSession()
    
    if (!session?.user?.email) {
      return null
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    return user
  } catch (error) {
    console.error('Error getting current user:', error)
    return null
  }
}

export async function requireAdmin() {
  const user = await getCurrentUser()
  
  if (!user) {
    throw new Error('Authentication required')
  }
  
  if (user.role !== 'admin') {
    throw new Error('Admin access required')
  }
  
  return user
}

export async function isAdmin(email?: string) {
  if (!email) return false
  
  try {
    const user = await db.user.findUnique({
      where: { email }
    })
    
    return user?.role === 'admin'
  } catch (error) {
    console.error('Error checking admin status:', error)
    return false
  }
}

// Client-side admin check
export function useIsAdmin(user?: any) {
  return user?.role === 'admin'
}