// Helper function to handle redirects safely
export function safeRedirect(url: string, fallback = '/dashboard') {
  try {
    // Check if we're already at the target URL
    if (typeof window !== 'undefined' && window.location.pathname === url) {
      console.log('safeRedirect: Already at target URL, not redirecting')
      return
    }
    
    console.log('safeRedirect: Redirecting to', url)
    
    // Use window.location.href for a hard redirect to avoid Next.js routing issues
    if (typeof window !== 'undefined') {
      window.location.href = url
    }
  } catch (error) {
    console.error('safeRedirect: Error during redirect', error)
    // Fallback to dashboard
    if (typeof window !== 'undefined') {
      window.location.href = fallback
    }
  }
}

// Helper function to get dashboard URL based on user role
export function getDashboardUrl(role?: string) {
  switch (role) {
    case 'restaurant_owner':
      return '/restaurant/dashboard'
    case 'admin':
      return '/admin'
    default:
      return '/dashboard'
  }
}

// Helper function to check if user needs onboarding
export function needsOnboarding(user: any) {
  if (!user) return false
  if (user.role === 'restaurant_owner') return false
  return !user.onboardingCompleted
}