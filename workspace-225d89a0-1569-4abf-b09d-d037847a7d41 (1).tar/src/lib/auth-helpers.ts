import { NextRequest } from 'next/server'
import { db } from '@/lib/db'

interface User {
  id: string
  email: string
  name?: string
  role: string
}

/**
 * Extract user information from request headers
 * This works with the custom token-based auth system
 */
export async function getCurrentUser(request: NextRequest): Promise<User | null> {
  try {
    // Get authorization header
    const authHeader = request.headers.get('authorization')
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null
    }

    const token = authHeader.substring(7) // Remove 'Bearer ' prefix
    
    // For now, we'll use a simple approach where the token is the user email
    // In a production system, you'd want to use proper JWT tokens
    const user = await db.user.findUnique({
      where: { email: token },
      select: {
        id: true,
        email: true,
        name: true,
        role: true
      }
    })

    return user
  } catch (error) {
    console.error('Error getting current user:', error)
    return null
  }
}

/**
 * Middleware to ensure user is authenticated
 */
export async function requireAuth(request: NextRequest): Promise<{ user: User; response?: never }> | { user?: never; response: Response } {
  const user = await getCurrentUser(request)
  
  if (!user) {
    return {
      response: new Response(
        JSON.stringify({ error: 'Unauthorized' }), 
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      )
    }
  }
  
  return { user }
}

/**
 * Middleware to ensure user has specific role
 */
export async function requireRole(
  request: NextRequest, 
  allowedRoles: string[]
): Promise<{ user: User; response?: never }> | { user?: never; response: Response } {
  const authResult = await requireAuth(request)
  
  if ('response' in authResult) {
    return authResult
  }
  
  const { user } = authResult
  
  if (!allowedRoles.includes(user.role)) {
    return {
      response: new Response(
        JSON.stringify({ error: 'Access denied' }), 
        { status: 403, headers: { 'Content-Type': 'application/json' } }
      )
    }
  }
  
  return { user }
}

/**
 * Get restaurant for the current restaurant owner
 */
export async function getRestaurantForOwner(ownerId: string) {
  return await db.restaurant.findFirst({
    where: { ownerId },
    select: { id: true, name: true }
  })
}