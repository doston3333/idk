/**
 * API helper functions that include authentication
 */

/**
 * Get auth headers for API requests
 */
export function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') {
    return {}
  }

  try {
    const storedUser = localStorage.getItem('user')
    if (storedUser) {
      const user = JSON.parse(storedUser)
      return {
        'Authorization': `Bearer ${user.email}`,
        'Content-Type': 'application/json'
      }
    }
  } catch (error) {
    console.error('Error getting auth headers:', error)
  }

  return {
    'Content-Type': 'application/json'
  }
}

/**
 * Make authenticated API request
 */
export async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const headers = {
    ...getAuthHeaders(),
    ...options.headers
  }

  return fetch(url, {
    ...options,
    headers
  })
}

/**
 * Make authenticated GET request
 */
export async function authGet(url: string): Promise<Response> {
  return authFetch(url, { method: 'GET' })
}

/**
 * Make authenticated POST request
 */
export async function authPost(url: string, data: any): Promise<Response> {
  return authFetch(url, {
    method: 'POST',
    body: JSON.stringify(data)
  })
}

/**
 * Make authenticated PATCH request
 */
export async function authPatch(url: string, data: any): Promise<Response> {
  return authFetch(url, {
    method: 'PATCH',
    body: JSON.stringify(data)
  })
}

/**
 * Make authenticated DELETE request
 */
export async function authDelete(url: string): Promise<Response> {
  return authFetch(url, { method: 'DELETE' })
}